const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const net = require('net');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const IS_WIN = process.platform === 'win32';
const RES = app.isPackaged ? process.resourcesPath : __dirname; // backend/ and resources/ live here
const BACKEND_DIR = path.join(RES, 'backend');
const BUNDLED_MODELS = app.isPackaged ? path.join(process.resourcesPath, 'models') : path.join(__dirname, 'resources', 'models');

let win = null;
let backend = { proc: null, status: { state: 'starting' } };
let starting = null;

// ---------------------------------------------------------------- settings
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile(), 'utf8')); } catch { return {}; }
}
function writeSettings(patch) {
  const s = { ...readSettings(), ...patch };
  fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
  fs.writeFileSync(settingsFile(), JSON.stringify(s, null, 2));
  return s;
}

// ---------------------------------------------------------------- python discovery
const venvDir = () => path.join(app.getPath('userData'), 'venv');
const venvPython = () => (IS_WIN ? path.join(venvDir(), 'Scripts', 'python.exe') : path.join(venvDir(), 'bin', 'python'));

function pythonCandidates() {
  const list = [];
  const s = readSettings();
  if (s.pythonPath) list.push({ cmd: s.pythonPath, args: [], label: s.pythonPath });
  if (fs.existsSync(venvPython())) list.push({ cmd: venvPython(), args: [], label: venvPython() });
  const local = IS_WIN ? path.join(__dirname, '.venv', 'Scripts', 'python.exe') : path.join(__dirname, '.venv', 'bin', 'python');
  if (fs.existsSync(local)) list.push({ cmd: local, args: [], label: local });
  if (IS_WIN) {
    list.push({ cmd: 'py', args: ['-3'], label: 'py -3' }, { cmd: 'python', args: [], label: 'python' });
  } else {
    list.push({ cmd: 'python3', args: [], label: 'python3' }, { cmd: 'python', args: [], label: 'python' });
  }
  return list;
}

function probePython(c) {
  try {
    const r = spawnSync(c.cmd, [...c.args, '--version'], { encoding: 'utf8', timeout: 8000, windowsHide: true });
    return r.status === 0 ? (r.stdout || r.stderr || '').trim() : null;
  } catch { return null; }
}

// ---------------------------------------------------------------- backend lifecycle
function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => { const { port } = srv.address(); srv.close(() => resolve(port)); });
    srv.on('error', reject);
  });
}

function setStatus(st) {
  backend.status = st;
  if (win && !win.isDestroyed()) win.webContents.send('backend:status', st);
}

async function waitHealth(port, token, ms) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/health`, { headers: { 'X-Token': token } });
      if (r.ok) return true;
    } catch { /* not yet */ }
    await new Promise((r) => setTimeout(r, 250));
  }
  return false;
}

function tryLaunch(cand, port, token) {
  return new Promise((resolve) => {
    let stderr = '';
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    let proc;
    try {
      proc = spawn(cand.cmd, [...cand.args, '-u', path.join(BACKEND_DIR, 'server.py'),
        '--port', String(port), '--token', token,
        '--data-dir', path.join(app.getPath('userData'), 'data'),
        '--bundled-dir', BUNDLED_MODELS], { windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
    } catch (e) { return finish({ ok: false, error: String(e) }); }
    proc.on('error', (e) => finish({ ok: false, error: e.code === 'ENOENT' ? 'not found' : String(e) }));
    proc.stderr.on('data', (d) => { stderr = (stderr + d.toString()).slice(-4000); });
    proc.stdout.on('data', (d) => {
      if (/READY/.test(d.toString())) waitHealth(port, token, 15000).then((ok) => ok ? finish({ ok: true, proc }) : finish({ ok: false, error: 'no health', stderr }));
    });
    proc.on('exit', (code) => {
      if (!done) finish({ ok: false, error: `exited with code ${code}`, stderr });
      else if (backend.proc === proc) { backend.proc = null; setStatus({ state: 'error', message: `Backend stopped (code ${code})`, stderr }); }
    });
    setTimeout(() => { if (!done) { try { proc.kill(); } catch {} finish({ ok: false, error: 'timeout', stderr }); } }, 30000);
  });
}

function stopBackend() {
  if (backend.proc) { try { backend.proc.kill(); } catch {} backend.proc = null; }
}

async function startBackend() {
  if (starting) return starting;
  starting = (async () => {
    stopBackend();
    setStatus({ state: 'starting' });
    const port = await freePort();
    const token = crypto.randomBytes(16).toString('hex');
    const tried = [];
    let lastErr = '';
    for (const cand of pythonCandidates()) {
      const ver = probePython(cand);
      if (!ver) { tried.push(`${cand.label}: not found`); continue; }
      const r = await tryLaunch(cand, port, token);
      if (r.ok) {
        backend.proc = r.proc;
        setStatus({ state: 'ready', port, token, python: cand.label, pythonVersion: ver });
        return;
      }
      lastErr = r.stderr || r.error || '';
      tried.push(`${cand.label} (${ver}): ${r.error}`);
    }
    setStatus({ state: 'error', message: tried.length ? 'Could not start the Python backend.' : 'Python was not found.', stderr: lastErr, tried });
  })().finally(() => { starting = null; });
  return starting;
}

// ---------------------------------------------------------------- dependency installer
let installing = false;
function runLogged(cmd, args, send) {
  return new Promise((resolve) => {
    send(`$ ${cmd} ${args.join(' ')}\n`);
    const p = spawn(cmd, args, { windowsHide: true });
    p.stdout.on('data', (d) => send(d.toString()));
    p.stderr.on('data', (d) => send(d.toString()));
    p.on('error', (e) => { send(`ERROR: ${e.message}\n`); resolve(1); });
    p.on('exit', (c) => resolve(c));
  });
}

async function installDeps() {
  if (installing) return { ok: false, error: 'busy' };
  installing = true;
  const send = (t) => win && !win.isDestroyed() && win.webContents.send('backend:install-log', t);
  try {
    stopBackend();
    const sys = pythonCandidates().find((c) => c.cmd !== venvPython() && probePython(c));
    if (!sys) { send('Python 3.9 - 3.13 was not found. Install it from python.org first, then retry.\n'); return { ok: false, error: 'no python' }; }
    if (!fs.existsSync(venvPython())) {
      send('Creating a private virtual environment...\n');
      const c = await runLogged(sys.cmd, [...sys.args, '-m', 'venv', venvDir()], send);
      if (c !== 0) return { ok: false, error: 'venv failed' };
    }
    const py = venvPython();
    await runLogged(py, ['-m', 'pip', 'install', '--upgrade', 'pip'], send);
    const code = await runLogged(py, ['-m', 'pip', 'install', '-r', path.join(BACKEND_DIR, 'requirements.txt')], send);
    if (code !== 0) return { ok: false, error: 'pip failed' };
    send('\nDone. Starting backend...\n');
    writeSettings({ pythonPath: py });
    return { ok: true };
  } finally {
    installing = false;
  }
}

// ---------------------------------------------------------------- window
function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 880, minWidth: 1120, minHeight: 700,
    backgroundColor: '#080c10', title: 'Brain Tumor Studio', show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  if (process.env.BTS_DEVTOOLS) win.webContents.openDevTools({ mode: 'detach' });
}

app.whenReady().then(() => {
  if (!process.env.BTS_DEVTOOLS) Menu.setApplicationMenu(null);
  createWindow();
  startBackend();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { stopBackend(); if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', stopBackend);

// ---------------------------------------------------------------- IPC
const IMG_FILTER = { name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'bmp', 'tif', 'tiff', 'webp'] };

ipcMain.handle('backend:status', () => backend.status);
ipcMain.handle('backend:restart', async () => { await startBackend(); return backend.status; });
ipcMain.handle('backend:install', async () => { const r = await installDeps(); await startBackend(); return r; });
ipcMain.handle('settings:get', () => readSettings());
ipcMain.handle('settings:set', (_e, patch) => writeSettings(patch));

ipcMain.handle('dialog:images', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile', 'multiSelections'], filters: [IMG_FILTER] });
  return r.canceled ? [] : r.filePaths;
});
ipcMain.handle('dialog:folder', async (_e, title) => {
  const r = await dialog.showOpenDialog(win, { title, properties: ['openDirectory', 'createDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('dialog:model', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Keras model', extensions: ['h5', 'keras', 'hdf5'] }] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('dialog:python', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('fs:writeDataUri', (_e, file, uri) => {
  const m = /^data:[^;]+;base64,(.*)$/.exec(uri || '');
  if (!m) throw new Error('bad data uri');
  fs.writeFileSync(file, Buffer.from(m[1], 'base64'));
  return true;
});
ipcMain.handle('fs:join', (_e, ...p) => path.join(...p));
ipcMain.handle('shell:show', (_e, p) => { shell.showItemInFolder(p); });
ipcMain.handle('shell:openFolder', (_e, p) => shell.openPath(p));
ipcMain.handle('app:info', () => ({ version: app.getVersion(), electron: process.versions.electron, platform: process.platform, userData: app.getPath('userData') }));
