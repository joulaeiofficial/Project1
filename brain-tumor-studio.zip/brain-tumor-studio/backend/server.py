"""
Brain Tumor Studio - local inference / training backend.

A small Flask server that Electron spawns on 127.0.0.1 (random port, random token).
It starts immediately; TensorFlow is imported in a background thread so the UI can
show a friendly status ("loading" / "ready" / "error: ...").
"""
import argparse
import base64
import json
import math
import os
import random
import sys
import threading
import time
import traceback
from collections import OrderedDict
from datetime import datetime
from pathlib import Path

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

import cv2
import numpy as np
from flask import Flask, Response, jsonify, request

IMG_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
MASK_SUFFIXES = ("_mask", "-mask", "_seg", "-seg", "_segmentation", "_label", "_gt", "_labels", "mask")
DISPLAY_MAX = 1024

# Overlay colours (BGR)
FILL_BGR = (90, 70, 255)
CONTOUR_BGR = (0, 205, 255)
CIRCLE_BGR = (255, 190, 40)

# --------------------------------------------------------------------------- #
# TensorFlow (lazy)
# --------------------------------------------------------------------------- #
TF = {"state": "loading", "error": None, "version": None}
tf = None
keras = None


def _import_tf():
    global tf, keras
    try:
        import tensorflow as _tf
        from tensorflow import keras as _keras

        tf, keras = _tf, _keras
        TF.update(state="ready", version=_tf.__version__, keras=_keras.__version__)
    except Exception as e:  # noqa: BLE001
        TF.update(state="error", error=f"{type(e).__name__}: {e}")


threading.Thread(target=_import_tf, daemon=True).start()


def need_tf():
    # wait a little if TF is still importing
    for _ in range(600):
        if TF["state"] != "loading":
            break
        time.sleep(0.1)
    if TF["state"] != "ready":
        raise ApiError(f"TensorFlow is not available: {TF.get('error') or 'still loading'}", 503, "tf_unavailable")


class ApiError(Exception):
    def __init__(self, message, status=400, code="error"):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code


# --------------------------------------------------------------------------- #
# Config / persisted state
# --------------------------------------------------------------------------- #
ARGS = None
DATA_DIR = Path(".")
MODELS_DIR = Path(".")
STATE_LOCK = threading.RLock()


def state_path():
    return DATA_DIR / "state.json"


def load_state():
    try:
        with open(state_path(), "r", encoding="utf-8") as f:
            s = json.load(f)
    except Exception:  # noqa: BLE001
        s = {}
    s.setdefault("models", [])
    s.setdefault("active", None)
    s.setdefault("dataset", None)
    s.setdefault("info", {})
    return s


def save_state(s):
    with STATE_LOCK:
        tmp = state_path().with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
        os.replace(tmp, state_path())


# --------------------------------------------------------------------------- #
# Image helpers (unicode-safe: np.fromfile + imdecode)
# --------------------------------------------------------------------------- #
def imread(path, gray=False):
    try:
        data = np.fromfile(str(path), dtype=np.uint8)
    except Exception:  # noqa: BLE001
        return None
    if data.size == 0:
        return None
    img = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE if gray else cv2.IMREAD_COLOR)
    return img


def enc(ext, img, quality=90):
    if ext == ".jpg":
        ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])
        mime = "jpeg"
    else:
        ok, buf = cv2.imencode(".png", img)
        mime = "png"
    if not ok:
        raise ApiError("image encode failed", 500)
    return mime, buf.tobytes()


def data_uri(ext, img, quality=90):
    mime, raw = enc(ext, img, quality)
    return f"data:image/{mime};base64,{base64.b64encode(raw).decode()}"


def is_image(p: Path):
    return p.is_file() and p.suffix.lower() in IMG_EXT


def list_images(root, recursive=True):
    root = Path(root)
    if not root.is_dir():
        raise ApiError(f"Folder not found: {root}", 404, "no_folder")
    it = root.rglob("*") if recursive else root.iterdir()
    return sorted([p for p in it if is_image(p)], key=lambda p: str(p).lower())


def strip_mask_suffix(stem):
    low = stem.lower()
    for suf in MASK_SUFFIXES:
        if low.endswith(suf) and len(stem) > len(suf):
            return stem[: -len(suf)], True
    return stem, False


def match_pairs(images_dir, masks_dir):
    """Match image files to mask files. Returns (pairs, unmatched_images, unmatched_masks)."""
    images_dir, masks_dir = Path(images_dir), Path(masks_dir)
    same_dir = images_dir.resolve() == masks_dir.resolve()
    imgs = list_images(images_dir)
    msks = list_images(masks_dir)

    if same_dir:
        imgs = [p for p in imgs if not strip_mask_suffix(p.stem)[1]]
        msks = [p for p in msks if strip_mask_suffix(p.stem)[1]]

    def rel_key(p, root):
        r = p.relative_to(root)
        return str(r.with_suffix("")).replace("\\", "/").lower()

    by_rel, by_stem = {}, {}
    stem_count = {}
    for m in msks:
        k = rel_key(m, masks_dir)
        base_k = k
        stripped, was = strip_mask_suffix(Path(k).name)
        if was:
            base_k = str(Path(k).parent / stripped).replace("\\", "/")
            if base_k.startswith("./"):
                base_k = base_k[2:]
        by_rel.setdefault(k, m)
        by_rel.setdefault(base_k, m)
        for s in {m.stem.lower(), stripped.lower()}:
            stem_count[s] = stem_count.get(s, 0) + 1
            by_stem.setdefault(s, m)

    pairs, un_imgs, used = [], [], set()
    for im in imgs:
        k = rel_key(im, images_dir)
        m = by_rel.get(k)
        if m is None and stem_count.get(im.stem.lower(), 0) == 1:
            m = by_stem.get(im.stem.lower())
        if m is None:
            un_imgs.append(im)
        else:
            pairs.append((im, m))
            used.add(str(m))
    un_msks = [m for m in msks if str(m) not in used]
    return pairs, un_imgs, un_msks


def binarize_mask(m):
    """uint8 gray mask -> {0,1}. Works for 0/255, 0/1 and slightly noisy (JPEG) masks."""
    if m.max() <= 1:
        return (m > 0).astype(np.uint8)
    return (m > 127).astype(np.uint8)


# --------------------------------------------------------------------------- #
# Model holder
# --------------------------------------------------------------------------- #
class Holder:
    model = None
    path = None
    lock = threading.Lock()


def model_shape(model):
    shp = model.input_shape
    if isinstance(shp, list):
        shp = shp[0]
    h = shp[1] or 128
    w = shp[2] or 128
    c = shp[3] or 3
    return int(h), int(w), int(c)


def summary_text(model):
    lines = []
    model.summary(print_fn=lambda s, *a, **k: lines.append(str(s)), line_length=100)
    return "\n".join(lines[:400])


def model_info(model, path):
    h, w, c = model_shape(model)
    p = Path(path)
    return {
        "name": p.stem,
        "path": str(p),
        "format": p.suffix.lower().lstrip("."),
        "size_bytes": p.stat().st_size if p.exists() else 0,
        "input_shape": [h, w, c],
        "output_shape": [int(x) if x else None for x in (model.output_shape[1:] if not isinstance(model.output_shape, list) else model.output_shape[0][1:])],
        "params": int(model.count_params()),
        "layers": len(model.layers),
    }


def load_model_file(path):
    need_tf()
    p = Path(path)
    if not p.is_file():
        raise ApiError(f"Model file not found: {p}", 404, "no_file")
    if p.suffix.lower() not in (".h5", ".keras", ".hdf5"):
        raise ApiError("Only .h5 / .keras / .hdf5 models are supported", 400, "bad_ext")
    try:
        return keras.models.load_model(str(p), compile=False)
    except Exception as e:  # noqa: BLE001
        raise ApiError(f"Could not load model: {type(e).__name__}: {e}", 422, "load_failed")


def read_meta(path):
    mp = Path(path).with_suffix(".meta.json")
    try:
        with open(mp, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # noqa: BLE001
        return None


def activate(path):
    model = load_model_file(path)
    info = model_info(model, path)
    info["summary"] = summary_text(model)
    with Holder.lock:
        Holder.model, Holder.path = model, str(path)
    with STATE_LOCK:
        s = load_state()
        if str(path) not in s["models"]:
            s["models"].append(str(path))
        s["active"] = str(path)
        s["info"][str(path)] = {k: v for k, v in info.items() if k != "summary"}
        save_state(s)
    return info


# --------------------------------------------------------------------------- #
# Prediction cache + rendering
# --------------------------------------------------------------------------- #
CACHE = OrderedDict()
CACHE_LOCK = threading.Lock()


def preprocess(img_bgr, shape):
    h, w, c = shape
    if c == 1:
        g = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        x = cv2.resize(g, (w, h))[..., None]
    else:
        x = cv2.resize(img_bgr, (w, h))  # BGR, like the original training code
    return x.astype("float32") / 255.0


def run_model(img_bgr):
    need_tf()
    with Holder.lock:
        model = Holder.model
        if model is None:
            raise ApiError("No active model. Choose one in the Models page.", 409, "no_model")
        shape = model_shape(model)
        x = preprocess(img_bgr, shape)[None]
        out = model.predict(x, verbose=0)
    out = out[0] if isinstance(out, (list, tuple)) else out
    p = out[0]
    p = p[..., -1] if p.shape[-1] > 1 else p[..., 0]
    return np.clip(p.astype("float32"), 0, 1)


def render(entry, p):
    img = entry["img"]
    H, W = img.shape[:2]
    full = bool(p.get("full"))
    s = 1.0 if (full or max(H, W) <= DISPLAY_MAX) else DISPLAY_MAX / max(H, W)
    dw, dh = max(1, int(round(W * s))), max(1, int(round(H * s)))
    base = cv2.resize(img, (dw, dh), interpolation=cv2.INTER_AREA) if s != 1.0 else img.copy()
    pm = cv2.resize(entry["probs"], (dw, dh), interpolation=cv2.INTER_LINEAR)

    thr = float(p.get("threshold", 0.5))
    min_pct = float(p.get("min_area", 0.0))
    alpha = float(p.get("opacity", 0.45))
    mask = (pm > thr).astype(np.uint8)
    res = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = list(res[-2])
    min_area = max(min_pct / 100.0 * dw * dh, 1.0)
    cnts = [c for c in cnts if cv2.contourArea(c) >= min_area]
    cnts.sort(key=cv2.contourArea, reverse=True)

    mask = np.zeros((dh, dw), np.uint8)
    if cnts:
        cv2.drawContours(mask, cnts, -1, 1, thickness=cv2.FILLED)

    th = max(1, int(round(max(dw, dh) / 380)))
    ov = base.copy()
    if p.get("fill", True) and mask.any():
        tint = np.empty_like(base)
        tint[:] = FILL_BGR
        blended = cv2.addWeighted(base, 1 - alpha, tint, alpha, 0)
        ov = np.where(mask[..., None] == 1, blended, base)
    regions = []
    for i, c in enumerate(cnts):
        if p.get("contour", True):
            cv2.drawContours(ov, [c], -1, CONTOUR_BGR, th, cv2.LINE_AA)
        (cx, cy), r = cv2.minEnclosingCircle(c)
        if p.get("circle", True):
            cv2.circle(ov, (int(cx), int(cy)), int(r) + th * 2, CIRCLE_BGR, th, cv2.LINE_AA)
        if i < 24:
            rm = np.zeros((dh, dw), np.uint8)
            cv2.drawContours(rm, [c], -1, 1, thickness=cv2.FILLED)
            area = float(rm.sum())
            regions.append({
                "area_pct": round(100.0 * area / (dw * dh), 3),
                "area_px": int(round(area / (s * s))),
                "cx": round(cx / dw, 4), "cy": round(cy / dh, 4),
                "confidence": round(float(pm[rm == 1].mean()), 3) if area else 0.0,
            })

    heat = cv2.applyColorMap((pm * 255).astype(np.uint8), cv2.COLORMAP_INFERNO)
    heat = cv2.addWeighted(base, 0.4, heat, 0.6, 0)

    ext = ".png" if full else ".jpg"
    total_pct = float(mask.sum()) * 100.0 / (dw * dh)
    return {
        "overlay": data_uri(ext, ov),
        "heat": data_uri(ext, heat),
        "mask": data_uri(".png", mask * 255),
        "stats": {
            "area_pct": round(total_pct, 3),
            "regions": len(cnts),
            "max_prob": round(float(pm.max()), 3),
            "mean_conf": round(float(pm[mask == 1].mean()), 3) if mask.any() else 0.0,
            "region_list": regions,
        },
    }


def cache_put(entry):
    with CACHE_LOCK:
        CACHE[entry["id"]] = entry
        while len(CACHE) > 16:
            CACHE.popitem(last=False)


# --------------------------------------------------------------------------- #
# Dataset
# --------------------------------------------------------------------------- #
def scan_dataset(images_dir, masks_dir):
    pairs, un_i, un_m = match_pairs(images_dir, masks_dir)
    n_img = len(pairs) + len(un_i)
    n_msk = len(pairs) + len(un_m)
    rng = random.Random(7)
    sample = rng.sample(pairs, min(40, len(pairs))) if pairs else []

    sizes, fracs, empties, kinds = {}, [], 0, {"binary_255": 0, "binary_01": 0, "gray": 0}
    ok_n = 0
    for im_p, mk_p in sample:
        im = imread(im_p)
        mk = imread(mk_p, gray=True)
        if im is None or mk is None:
            continue
        ok_n += 1
        key = f"{im.shape[1]}x{im.shape[0]}"
        sizes[key] = sizes.get(key, 0) + 1
        u = np.unique(mk)
        if len(u) <= 2 and u.max() <= 1:
            kinds["binary_01"] += 1
        elif len(u) <= 2 and u.max() == 255:
            kinds["binary_255"] += 1
        else:
            kinds["gray"] += 1
        b = binarize_mask(mk)
        fracs.append(float(b.mean()))
        if b.sum() == 0:
            empties += 1

    warnings = []
    if len(pairs) == 0:
        warnings.append("no_pairs")
    elif len(pairs) < 100:
        warnings.append("few_pairs")
    if un_i:
        warnings.append("unmatched_images")
    if ok_n and kinds["binary_01"] > ok_n / 2:
        warnings.append("mask_01")
    if ok_n and kinds["gray"] > ok_n / 2:
        warnings.append("mask_gray")
    mean_frac = float(np.mean(fracs)) if fracs else 0.0
    if fracs and mean_frac < 0.03:
        warnings.append("imbalance")
    if ok_n and empties / ok_n > 0.5:
        warnings.append("many_empty")

    return {
        "images_dir": str(images_dir), "masks_dir": str(masks_dir),
        "n_images": n_img, "n_masks": n_msk, "n_pairs": len(pairs),
        "unmatched_images": [str(p) for p in un_i[:8]],
        "unmatched_masks": [str(p) for p in un_m[:8]],
        "sizes": sorted(sizes.items(), key=lambda kv: -kv[1])[:4],
        "mask_kind": max(kinds, key=kinds.get) if ok_n else None,
        "mean_mask_fraction": round(mean_frac, 4),
        "empty_fraction": round(empties / ok_n, 3) if ok_n else 0,
        "warnings": warnings,
        "samples": [{"image": str(a), "mask": str(b)} for a, b in pairs[:: max(1, len(pairs) // 8)][:8]],
    }


# --------------------------------------------------------------------------- #
# Training
# --------------------------------------------------------------------------- #
PRESETS = {  # depth, base filters, batchnorm, dropout
    "simple": (1, 64, False, 0.0),
    "light": (3, 16, True, 0.1),
    "standard": (4, 32, True, 0.1),
    "deep": (5, 32, True, 0.2),
}

TRAIN = {"status": "idle"}
TRAIN_LOCK = threading.Lock()
STOP_FLAG = threading.Event()


def tlog(msg):
    with TRAIN_LOCK:
        TRAIN.setdefault("log", []).append(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
        TRAIN["log"] = TRAIN["log"][-300:]


def build_unet(size, channels, preset):
    L = keras.layers
    depth, base, bn, drop = PRESETS[preset]

    def block(x, f):
        for _ in range(2):
            x = L.Conv2D(f, 3, padding="same", use_bias=not bn, kernel_initializer="he_normal")(x)
            if bn:
                x = L.BatchNormalization()(x)
            x = L.Activation("relu")(x)
        if drop:
            x = L.Dropout(drop)(x)
        return x

    inp = L.Input((size, size, channels))
    x, skips = inp, []
    for d in range(depth):
        x = block(x, base * 2 ** d)
        skips.append(x)
        x = L.MaxPooling2D(2)(x)
    x = block(x, base * 2 ** depth)
    for d in reversed(range(depth)):
        x = L.Conv2DTranspose(base * 2 ** d, 2, strides=2, padding="same")(x)
        x = L.concatenate([x, skips[d]])
        x = block(x, base * 2 ** d)
    out = L.Conv2D(1, 1, activation="sigmoid")(x)
    return keras.Model(inp, out, name=f"unet_{preset}")


def _flat(t):
    return tf.reshape(t, [tf.shape(t)[0], -1])


def dice(y_true, y_pred):
    yt = _flat(tf.cast(y_true, "float32"))
    yp = _flat(tf.cast(y_pred > 0.5, "float32"))
    inter = tf.reduce_sum(yt * yp, 1)
    return tf.reduce_mean((2 * inter + 1.0) / (tf.reduce_sum(yt, 1) + tf.reduce_sum(yp, 1) + 1.0))


def iou(y_true, y_pred):
    yt = _flat(tf.cast(y_true, "float32"))
    yp = _flat(tf.cast(y_pred > 0.5, "float32"))
    inter = tf.reduce_sum(yt * yp, 1)
    union = tf.reduce_sum(yt, 1) + tf.reduce_sum(yp, 1) - inter
    return tf.reduce_mean((inter + 1.0) / (union + 1.0))


def soft_dice_loss(y_true, y_pred):
    yt = _flat(tf.cast(y_true, "float32"))
    yp = _flat(y_pred)
    inter = tf.reduce_sum(yt * yp, 1)
    d = (2 * inter + 1.0) / (tf.reduce_sum(yt, 1) + tf.reduce_sum(yp, 1) + 1.0)
    return 1.0 - tf.reduce_mean(d)


def bce_dice_loss(y_true, y_pred):
    bce = tf.reduce_mean(keras.losses.binary_crossentropy(y_true, y_pred))
    return bce + soft_dice_loss(y_true, y_pred)


def load_arrays(pairs, size, channels):
    n = len(pairs)
    X = np.zeros((n, size, size, channels), np.uint8)
    Y = np.zeros((n, size, size, 1), np.uint8)
    keep = 0
    for i, (ip, mp) in enumerate(pairs):
        if STOP_FLAG.is_set():
            raise ApiError("stopped", 499, "stopped")
        im, mk = imread(ip), imread(mp, gray=True)
        if im is not None and mk is not None:
            if channels == 1:
                im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)[..., None]
            X[keep] = cv2.resize(im, (size, size)).reshape(size, size, channels)
            Y[keep, ..., 0] = cv2.resize(binarize_mask(mk) * 255, (size, size), interpolation=cv2.INTER_NEAREST) > 127
            keep += 1
        if i % 20 == 0:
            with TRAIN_LOCK:
                TRAIN["load_progress"] = round((i + 1) / n, 3)
    return X[:keep], Y[:keep]


def make_sequence(X, Y, idx, bs, aug, shuffle):
    class Seq(keras.utils.Sequence):
        def __init__(self):
            super().__init__()
            self.idx = np.array(idx)
            if shuffle:
                np.random.shuffle(self.idx)

        def __len__(self):
            return int(math.ceil(len(self.idx) / bs))

        def __getitem__(self, i):
            ids = self.idx[i * bs:(i + 1) * bs]
            x = X[ids].astype("float32") / 255.0
            y = Y[ids].astype("float32")
            if aug:
                for j in range(len(ids)):
                    if random.random() < 0.5:
                        x[j], y[j] = x[j][:, ::-1], y[j][:, ::-1]
                    if random.random() < 0.5:
                        x[j], y[j] = x[j][::-1], y[j][::-1]
                    k = random.randint(0, 3)
                    if k:
                        x[j], y[j] = np.rot90(x[j], k), np.rot90(y[j], k)
                    x[j] = np.clip(x[j] * random.uniform(0.85, 1.15) + random.uniform(-0.05, 0.05), 0, 1)
            return np.ascontiguousarray(x), np.ascontiguousarray(y)

        def on_epoch_end(self):
            if shuffle:
                np.random.shuffle(self.idx)

    return Seq()


def train_worker(cfg):
    try:
        need_tf()
        STOP_FLAG.clear()
        size, ch = int(cfg["image_size"]), int(cfg.get("channels", 3))
        with TRAIN_LOCK:
            TRAIN.update(status="running", phase="loading_data", load_progress=0.0, epoch=0, batch=0, batches=0,
                         epochs=int(cfg["epochs"]), history={}, log=[], config=cfg, best=None, error=None,
                         started_at=time.time(), out_path=cfg["out_path"])
        tlog("Scanning dataset ...")
        pairs, _, _ = match_pairs(cfg["images_dir"], cfg["masks_dir"])
        if len(pairs) < 4:
            raise ApiError("Need at least 4 matched image/mask pairs", 400, "few_pairs")
        tlog(f"{len(pairs)} image/mask pairs found. Loading at {size}x{size} ...")
        X, Y = load_arrays(pairs, size, ch)
        n = len(X)
        tlog(f"Loaded {n} samples ({X.nbytes / 1e6:.0f} MB).")

        rng = np.random.RandomState(42)
        order = rng.permutation(n)
        n_val = int(round(n * float(cfg["val_split"])))
        val_idx, tr_idx = order[:n_val], order[n_val:]
        bs = int(cfg["batch_size"])
        train_seq = make_sequence(X, Y, tr_idx, bs, bool(cfg.get("augment")), True)
        val_seq = make_sequence(X, Y, val_idx, bs, False, False) if n_val else None

        with TRAIN_LOCK:
            TRAIN.update(phase="building")
        if cfg["init"] == "active":
            with Holder.lock:
                if Holder.model is None:
                    raise ApiError("No active model to continue from", 409, "no_model")
                path = Holder.path
            model = load_model_file(path)
            hh, ww, cc = model_shape(model)
            if (hh, ww, cc) != (size, size, ch):
                raise ApiError(f"Active model expects {hh}x{ww}x{cc}; set image size to match.", 400, "shape_mismatch")
            tlog(f"Continuing from {Path(path).name}")
        else:
            model = build_unet(size, ch, cfg["preset"])
            tlog(f"Built U-Net '{cfg['preset']}' - {model.count_params():,} parameters")

        loss = bce_dice_loss if cfg["loss"] == "bce_dice" else "binary_crossentropy"
        model.compile(optimizer=keras.optimizers.Adam(float(cfg["lr"])), loss=loss, metrics=[dice, iou, "accuracy"])

        out_path = Path(cfg["out_path"])
        out_path.parent.mkdir(parents=True, exist_ok=True)
        monitor = "val_dice" if n_val else "dice"

        class Progress(keras.callbacks.Callback):
            def on_epoch_begin(self, epoch, logs=None):
                with TRAIN_LOCK:
                    TRAIN.update(epoch=epoch + 1, batch=0, batches=len(train_seq))

            def on_train_batch_end(self, batch, logs=None):
                with TRAIN_LOCK:
                    TRAIN["batch"] = batch + 1
                    TRAIN["live"] = {k: float(v) for k, v in (logs or {}).items()}
                if STOP_FLAG.is_set():
                    self.model.stop_training = True

            def on_epoch_end(self, epoch, logs=None):
                logs = {k: float(v) for k, v in (logs or {}).items()}
                with TRAIN_LOCK:
                    h = TRAIN["history"]
                    for k, v in logs.items():
                        h.setdefault(k, []).append(v)
                    cur = logs.get(monitor)
                    if cur is not None and (TRAIN["best"] is None or cur > TRAIN["best"]):
                        TRAIN["best"] = cur
                tlog(f"Epoch {epoch + 1}/{cfg['epochs']}  loss={logs.get('loss', 0):.4f}  dice={logs.get('dice', 0):.4f}"
                     + (f"  val_dice={logs['val_dice']:.4f}  val_iou={logs.get('val_iou', 0):.4f}" if "val_dice" in logs else ""))

        cbs = [
            Progress(),
            keras.callbacks.ModelCheckpoint(str(out_path), monitor=monitor, mode="max", save_best_only=True, verbose=0),
            keras.callbacks.ReduceLROnPlateau(monitor="val_loss" if n_val else "loss", factor=0.5, patience=3, min_lr=1e-6, verbose=0),
        ]
        with TRAIN_LOCK:
            TRAIN.update(phase="training")
        tlog(f"Training: {len(tr_idx)} train / {n_val} val, batch {bs}, lr {cfg['lr']}, loss {cfg['loss']}")
        model.fit(train_seq, validation_data=val_seq, epochs=int(cfg["epochs"]), callbacks=cbs, verbose=0)

        with TRAIN_LOCK:
            TRAIN["phase"] = "saving"
        if not out_path.exists():
            model.save(str(out_path))
        meta = {
            "name": out_path.stem, "created": datetime.now().isoformat(timespec="seconds"),
            "image_size": size, "channels": ch, "channel_order": "BGR", "preset": cfg["preset"] if cfg["init"] == "new" else "continued",
            "loss": cfg["loss"], "epochs_run": len(TRAIN["history"].get("loss", [])), "best_" + monitor: TRAIN["best"],
            "pairs": n, "dataset": {"images_dir": cfg["images_dir"], "masks_dir": cfg["masks_dir"]},
        }
        with open(out_path.with_suffix(".meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        activate(str(out_path))
        stopped = STOP_FLAG.is_set()
        tlog("Stopped early - best model saved and activated." if stopped else "Done - best model saved and activated.")
        with TRAIN_LOCK:
            TRAIN.update(status="stopped" if stopped else "done", phase="done")
        del model, X, Y
    except ApiError as e:
        with TRAIN_LOCK:
            if e.code == "stopped":
                TRAIN.update(status="stopped", phase="done")
            else:
                TRAIN.update(status="error", error=e.message)
        tlog(f"ERROR: {e.message}")
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        with TRAIN_LOCK:
            TRAIN.update(status="error", error=f"{type(e).__name__}: {e}")
        tlog(f"ERROR: {type(e).__name__}: {e}")


# --------------------------------------------------------------------------- #
# Flask
# --------------------------------------------------------------------------- #
app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False


@app.before_request
def _auth():
    if request.method == "OPTIONS":
        return Response(status=204)
    token = request.headers.get("X-Token") or request.args.get("token")
    if ARGS.token and token != ARGS.token:
        return jsonify(error="unauthorized", code="unauthorized"), 401


@app.after_request
def _cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "X-Token, Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
    return resp


@app.errorhandler(ApiError)
def _api_error(e):
    return jsonify(error=e.message, code=e.code), e.status


@app.errorhandler(Exception)
def _any_error(e):
    traceback.print_exc()
    return jsonify(error=f"{type(e).__name__}: {e}", code="internal"), 500


def body():
    return request.get_json(silent=True) or {}


@app.get("/health")
def health():
    s = load_state()
    return jsonify(ok=True, tf=TF, active=Holder.path, models_dir=str(MODELS_DIR), data_dir=str(DATA_DIR),
                   python=sys.version.split()[0], cv2=cv2.__version__, dataset=s.get("dataset"),
                   training=TRAIN.get("status"))


@app.get("/models")
def models_list():
    s = load_state()
    out, seen = [], set()
    paths = list(s["models"])
    for p in sorted(MODELS_DIR.glob("*")):
        if p.suffix.lower() in (".h5", ".keras", ".hdf5") and str(p) not in paths:
            paths.append(str(p))
    for ps in paths:
        if ps in seen:
            continue
        seen.add(ps)
        p = Path(ps)
        info = s["info"].get(ps, {})
        out.append({
            "path": ps, "name": p.stem, "format": p.suffix.lower().lstrip("."), "exists": p.exists(),
            "size_bytes": p.stat().st_size if p.exists() else 0,
            "active": ps == Holder.path,
            "bundled": ARGS.bundled_dir and str(p.parent) == str(Path(ARGS.bundled_dir)),
            "in_library": str(p.parent) == str(MODELS_DIR),
            "info": info, "meta": read_meta(ps) if p.exists() else None,
        })
    return jsonify(models=out, active=Holder.path)


@app.post("/models/register")
def models_register():
    path = body().get("path")
    if not path:
        raise ApiError("path required")
    copy = bool(body().get("copy"))
    p = Path(path)
    model = load_model_file(p)  # validates
    if copy and p.parent != MODELS_DIR:
        import shutil
        dest = MODELS_DIR / p.name
        i = 1
        while dest.exists():
            dest = MODELS_DIR / f"{p.stem}_{i}{p.suffix}"
            i += 1
        shutil.copy2(p, dest)
        p = dest
    info = model_info(model, p)
    with STATE_LOCK:
        s = load_state()
        if str(p) not in s["models"]:
            s["models"].append(str(p))
        s["info"][str(p)] = info
        save_state(s)
    return jsonify(ok=True, model=info)


@app.post("/models/remove")
def models_remove():
    path = body().get("path")
    delete_file = bool(body().get("delete_file"))
    with STATE_LOCK:
        s = load_state()
        s["models"] = [m for m in s["models"] if m != path]
        s["info"].pop(path, None)
        if s["active"] == path:
            s["active"] = None
        save_state(s)
    if Holder.path == path:
        with Holder.lock:
            Holder.model, Holder.path = None, None
    if delete_file and path and Path(path).parent == MODELS_DIR:
        for f in (Path(path), Path(path).with_suffix(".meta.json")):
            try:
                f.unlink()
            except OSError:
                pass
    return jsonify(ok=True)


@app.post("/models/activate")
def models_activate():
    path = body().get("path")
    if not path:
        raise ApiError("path required")
    return jsonify(ok=True, model=activate(path))


@app.get("/models/active")
def models_active():
    if Holder.model is None:
        return jsonify(model=None)
    info = model_info(Holder.model, Holder.path)
    info["summary"] = summary_text(Holder.model)
    info["meta"] = read_meta(Holder.path)
    return jsonify(model=info)


@app.post("/fs/images")
def fs_images():
    files = list_images(body().get("dir", ""), recursive=bool(body().get("recursive", True)))
    return jsonify(files=[str(f) for f in files[:5000]], total=len(files))


@app.get("/thumb")
def thumb():
    path = request.args.get("path", "")
    size = max(32, min(1024, int(request.args.get("size", 256))))
    img = imread(path)
    if img is None:
        raise ApiError("cannot read image", 404)
    h, w = img.shape[:2]
    s = size / max(h, w)
    if s < 1:
        img = cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    mpath = request.args.get("mask")
    if mpath:
        mk = imread(mpath, gray=True)
        if mk is not None:
            mk = cv2.resize(binarize_mask(mk), (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST)
            tint = np.empty_like(img)
            tint[:] = FILL_BGR
            img = np.where(mk[..., None] == 1, cv2.addWeighted(img, 0.5, tint, 0.5, 0), img)
            res = cv2.findContours(mk.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(img, res[-2], -1, CONTOUR_BGR, 1, cv2.LINE_AA)
    mime, raw = enc(".jpg", img, 82)
    r = Response(raw, mimetype=f"image/{mime}")
    r.headers["Cache-Control"] = "max-age=300"
    return r


@app.post("/predict")
def predict():
    b = body()
    path = b.get("path")
    img = imread(path)
    if img is None:
        raise ApiError(f"Cannot read image: {path}", 422, "bad_image")
    t0 = time.time()
    probs = run_model(img)
    ms = int((time.time() - t0) * 1000)
    entry = {"id": base64.urlsafe_b64encode(os.urandom(9)).decode(), "img": img, "probs": probs, "path": path}
    cache_put(entry)
    H, W = img.shape[:2]
    r = render(entry, b)
    s = 1.0 if max(H, W) <= DISPLAY_MAX else DISPLAY_MAX / max(H, W)
    disp = cv2.resize(img, (int(W * s), int(H * s)), interpolation=cv2.INTER_AREA) if s != 1.0 else img
    r.update(id=entry["id"], width=W, height=H, ms=ms, original=data_uri(".jpg", disp),
             model=Path(Holder.path).stem if Holder.path else None)
    return jsonify(r)


@app.post("/render")
def render_again():
    b = body()
    with CACHE_LOCK:
        entry = CACHE.get(b.get("id"))
    if entry is None:
        raise ApiError("Prediction expired, run it again", 410, "expired")
    return jsonify(render(entry, b))


@app.post("/dataset/scan")
def dataset_scan():
    b = body()
    r = scan_dataset(b.get("images_dir", ""), b.get("masks_dir", ""))
    with STATE_LOCK:
        s = load_state()
        s["dataset"] = {"images_dir": r["images_dir"], "masks_dir": r["masks_dir"], "n_pairs": r["n_pairs"]}
        save_state(s)
    return jsonify(r)


@app.get("/dataset/current")
def dataset_current():
    return jsonify(dataset=load_state().get("dataset"))


@app.post("/train/start")
def train_start():
    need_tf()
    cfg = body()
    with TRAIN_LOCK:
        if TRAIN.get("status") in ("running",):
            raise ApiError("Training is already running", 409, "busy")
    for k in ("images_dir", "masks_dir", "image_size", "epochs", "batch_size", "lr", "val_split", "loss", "init", "preset"):
        if k not in cfg:
            raise ApiError(f"missing field: {k}")
    if cfg["preset"] not in PRESETS:
        raise ApiError("unknown preset")
    size = int(cfg["image_size"])
    depth = PRESETS[cfg["preset"]][0]
    if cfg["init"] == "new" and size % (2 ** depth):
        raise ApiError(f"Image size must be divisible by {2 ** depth} for this preset")
    name = "".join(ch for ch in str(cfg.get("name") or "unet_model") if ch.isalnum() or ch in "-_ .").strip() or "unet_model"
    ext = cfg.get("format", "keras")
    cfg["out_path"] = str(MODELS_DIR / f"{name}.{ext}")
    with TRAIN_LOCK:
        TRAIN.clear()
        TRAIN.update(status="running", phase="starting")
    threading.Thread(target=train_worker, args=(cfg,), daemon=True).start()
    return jsonify(ok=True, out_path=cfg["out_path"])


@app.get("/train/status")
def train_status():
    with TRAIN_LOCK:
        d = json.loads(json.dumps(TRAIN, default=str))
    return jsonify(d)


@app.post("/train/stop")
def train_stop():
    STOP_FLAG.set()
    return jsonify(ok=True)


def main():
    global ARGS, DATA_DIR, MODELS_DIR
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=5731)
    ap.add_argument("--token", default="")
    ap.add_argument("--data-dir", default=str(Path.home() / ".brain-tumor-studio"))
    ap.add_argument("--bundled-dir", default="")
    ARGS = ap.parse_args()
    DATA_DIR = Path(ARGS.data_dir)
    MODELS_DIR = DATA_DIR / "models"
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    # register bundled models, then restore the last active one in the background
    s = load_state()
    if ARGS.bundled_dir and Path(ARGS.bundled_dir).is_dir():
        for p in sorted(Path(ARGS.bundled_dir).glob("*")):
            if p.suffix.lower() in (".h5", ".keras") and str(p) not in s["models"]:
                s["models"].append(str(p))
        if not s["active"]:
            first = next((m for m in s["models"] if Path(m).exists()), None)
            s["active"] = first
        save_state(s)

    def restore():
        s2 = load_state()
        if s2.get("active") and Path(s2["active"]).exists():
            try:
                activate(s2["active"])
            except Exception as e:  # noqa: BLE001
                print("restore active model failed:", e, file=sys.stderr)

    threading.Thread(target=restore, daemon=True).start()
    print(f"READY {ARGS.port}", flush=True)
    app.run(host="127.0.0.1", port=ARGS.port, threaded=True, debug=False)


if __name__ == "__main__":
    main()
