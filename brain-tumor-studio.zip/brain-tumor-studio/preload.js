const { contextBridge, ipcRenderer, webUtils } = require('electron');

const invoke = (ch) => (...a) => ipcRenderer.invoke(ch, ...a);

contextBridge.exposeInMainWorld('native', {
  getBackend: invoke('backend:status'),
  restartBackend: invoke('backend:restart'),
  installDeps: invoke('backend:install'),
  onBackend: (cb) => ipcRenderer.on('backend:status', (_e, s) => cb(s)),
  onInstallLog: (cb) => ipcRenderer.on('backend:install-log', (_e, t) => cb(t)),
  getSettings: invoke('settings:get'),
  setSettings: invoke('settings:set'),
  pickImages: invoke('dialog:images'),
  pickFolder: invoke('dialog:folder'),
  pickModel: invoke('dialog:model'),
  pickPython: invoke('dialog:python'),
  writeDataUri: invoke('fs:writeDataUri'),
  join: invoke('fs:join'),
  showInFolder: invoke('shell:show'),
  openFolder: invoke('shell:openFolder'),
  appInfo: invoke('app:info'),
  pathForFile: (file) => webUtils.getPathForFile(file),
});
