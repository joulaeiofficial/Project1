/* Models page */
const MD = { root: null, list: [], active: null, detail: null, loading: false };

async function mdRefresh() {
  if (APP.backend.state !== 'ready') return;
  try {
    const r = await API.call('/models');
    MD.list = r.models; MD.active = r.active;
    try { MD.detail = (await API.call('/models/active')).model; } catch { MD.detail = null; }
  } catch (e) { /* tf still loading */ }
  mdMount(MD.root);
}

function mdMount(root) {
  MD.root = root;
  root.innerHTML = `
  <div class="h-full overflow-y-auto"><div class="p-6 max-w-5xl mx-auto flex flex-col gap-5">
    <header class="flex items-center justify-between gap-4">
      <div><h1 class="text-2xl font-bold">${t('m.title')}</h1><p class="text-sm text-ink-400 mt-1">${t('m.sub')}</p></div>
      <button class="btn btn-primary" data-act="import">${icon('plus', 'w-4 h-4')}${t('m.import')}</button>
    </header>
    <div class="grid grid-cols-2 gap-4">${MD.list.length ? MD.list.map(mdCard).join('') : `<div class="card p-8 text-center text-ink-400 col-span-2">${t('m.empty')}</div>`}</div>
    <section class="card p-5 flex gap-4 items-start"><div class="w-10 h-10 shrink-0 rounded-xl grid place-items-center bg-sky-400/10 text-sky-400">${icon('info', 'w-5 h-5')}</div>
      <div><h3 class="font-bold mb-1">${t('m.expect.title')}</h3><p class="text-sm text-ink-300 leading-7">${t('m.expect.body')}</p></div></section>
    ${MD.detail ? `<section class="card p-5"><div class="flex items-center justify-between"><h3 class="font-bold">${t('m.arch')} <span class="text-ink-400 font-normal ltr">— ${esc(MD.detail.name)}</span></h3>
      <button class="btn btn-sm" data-act="arch">${icon('layers', 'w-3.5 h-3.5')}${t('m.showArch')}</button></div>
      <pre id="md-arch" class="hidden mt-4 rounded-xl bg-ink-950 border border-ink-700 p-4 text-[11px] leading-5 text-ink-300 overflow-auto max-h-96 ltr font-mono">${esc(MD.detail.summary)}</pre></section>` : ''}
  </div></div>`;
  root.onclick = mdClick;
}

function mdCard(m) {
  const i = m.info || {};
  const meta = m.meta || {};
  const kv = (k, v) => `<div class="rounded-lg bg-ink-900 border border-ink-700/60 px-2.5 py-2"><div class="stat-k">${k}</div><div class="text-sm font-medium mt-0.5 ltr">${v}</div></div>`;
  const dice = meta.best_val_dice ?? meta.best_dice;
  return `<article class="card p-4 flex flex-col gap-3 ${m.active ? 'ring-1 ring-mint-400/50 shadow-glow' : ''} ${m.exists ? '' : 'opacity-60'}">
    <div class="flex items-start gap-3">
      <div class="w-10 h-10 shrink-0 rounded-xl grid place-items-center ${m.active ? 'bg-mint-400 text-[rgb(var(--on-mint))]' : 'bg-ink-800 text-ink-300'}">${icon('models', 'w-5 h-5')}</div>
      <div class="min-w-0 flex-1"><div class="font-bold truncate ltr" title="${esc(m.path)}">${esc(m.name)}</div>
        <div class="flex flex-wrap gap-1.5 mt-1.5">
          ${m.active ? `<span class="chip chip-mint">${icon('check', 'w-3 h-3')}${t('m.active')}</span>` : ''}
          ${m.bundled ? `<span class="chip">${t('m.bundled')}</span>` : ''}${meta.created ? `<span class="chip chip-amber">${t('m.trained')}</span>` : ''}
          ${m.exists ? '' : `<span class="chip chip-rose">${t('m.missing')}</span>`}</div></div></div>
    <div class="grid grid-cols-3 gap-2">
      ${kv(t('m.input'), i.input_shape ? i.input_shape.join('×') : '—')}${kv(t('m.size'), fmtBytes(m.size_bytes))}${kv(t('common.params'), i.params ? fmtParams(i.params) : '—')}
      ${kv(t('m.format'), '.' + m.format)}${kv(t('m.epochs'), meta.epochs_run ?? '—')}${kv(t('m.bestDice'), dice != null ? dice.toFixed(3) : '—')}
    </div>
    <div class="flex gap-2 mt-1">
      ${m.active ? '' : `<button class="btn btn-primary btn-sm" data-act="activate" data-path="${esc(m.path)}" ${m.exists ? '' : 'disabled'}>${icon('zap', 'w-3.5 h-3.5')}${t('m.activate')}</button>`}
      <button class="btn btn-sm" data-act="show" data-path="${esc(m.path)}">${t('common.show')}</button>
      <button class="btn btn-ghost btn-sm ms-auto text-ink-400 hover:text-rose-400" data-act="remove" data-path="${esc(m.path)}">${icon('trash', 'w-3.5 h-3.5')}${t('common.remove')}</button>
    </div></article>`;
}

async function mdActivate(path) {
  const tid = setTimeout(() => toast(t('m.validating')), 400);
  try { await API.call('/models/activate', { path }); toast(t('m.activated'), 'ok'); }
  catch (e) { toast(e.message, 'err', 6000); }
  clearTimeout(tid);
  await mdRefresh();
  APP.health = await API.call('/health').catch(() => APP.health); renderSidebar();
}

async function mdImport() {
  const path = await native.pickModel();
  if (!path) return;
  const body = document.createElement('div');
  body.innerHTML = `<div class="ltr font-mono text-xs rounded-xl bg-ink-900 border border-ink-700 px-3 py-2.5 break-all">${esc(path)}</div>
    <label class="flex items-center gap-2.5 mt-4 cursor-pointer"><input type="checkbox" id="md-copy" /><span>${t('m.copy')}</span></label>`;
  const run = async (activate) => {
    const copy = $('#md-copy').checked;
    try {
      toast(t('m.validating'));
      const r = await API.call('/models/register', { path, copy });
      toast(t('m.added'), 'ok');
      if (activate) await API.call('/models/activate', { path: r.model.path });
    } catch (e) { toast(e.message, 'err', 7000); }
    await mdRefresh(); APP.health = await API.call('/health').catch(() => APP.health); renderSidebar();
  };
  modal({ title: t('m.importTitle'), body, actions: [
    { label: t('common.cancel') },
    { label: t('common.add'), onClick: () => run(false) },
    { label: t('m.addActivate'), cls: 'btn-primary', onClick: () => run(true) },
  ] });
}

async function mdClick(e) {
  const a = e.target.closest('[data-act]');
  if (!a) return;
  const path = a.dataset.path;
  switch (a.dataset.act) {
    case 'import': return mdImport();
    case 'activate': return mdActivate(path);
    case 'show': return native.showInFolder(path);
    case 'arch': return $('#md-arch').classList.toggle('hidden');
    case 'remove':
      return modal({ title: t('common.remove'), body: t('m.removeConfirm'), actions: [{ label: t('common.cancel') }, { label: t('common.remove'), cls: 'btn-danger', onClick: async () => { await API.call('/models/remove', { path }); toast(t('m.removed')); mdRefresh(); } }] });
  }
}

registerPage('models', { mount: mdMount, show: mdRefresh });
document.addEventListener('backend-ready', () => setTimeout(mdRefresh, 500));
document.addEventListener('active-model-changed', () => { if (APP.page === 'models') mdRefresh(); });
