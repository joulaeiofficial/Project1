/* Train page */
const TR = {
  root: null, st: { status: 'idle' }, timer: null,
  cfg: { name: 'unet_brain', format: 'keras', preset: 'light', init: 'new', image_size: 128, epochs: 15, batch_size: 8, lr: 0.001, val_split: 0.15, loss: 'bce_dice', augment: true },
};
try { Object.assign(TR.cfg, JSON.parse(localStorage.getItem('bts.train') || '{}')); } catch {}
const PRESET_PARAMS = { simple: '0.4M', light: '0.5M', standard: '7.8M', deep: '31M' };

const trDataset = () => {
  if (DS.images && DS.masks) return { images_dir: DS.images, masks_dir: DS.masks, n_pairs: DS.result ? DS.result.n_pairs : null };
  const d = APP.health && APP.health.dataset;
  return d ? { images_dir: d.images_dir, masks_dir: d.masks_dir, n_pairs: d.n_pairs } : null;
};
const trRunning = () => TR.st.status === 'running';

function trMount(root) {
  TR.root = root;
  const c = TR.cfg;
  const opt = (v, cur, label) => `<option value="${v}" ${String(cur) === String(v) ? 'selected' : ''}>${label}</option>`;
  const field = (label, html) => `<div><label class="label">${label}</label>${html}</div>`;
  const ds = trDataset();
  root.innerHTML = `
  <div class="h-full overflow-y-auto"><div class="p-6 max-w-[1180px] mx-auto">
    <header class="mb-5"><h1 class="text-2xl font-bold">${t('t.title')}</h1><p class="text-sm text-ink-400 mt-1">${t('t.sub')}</p></header>
    <div class="grid grid-cols-[400px_minmax(0,1fr)] gap-5 items-start">
      <section class="card p-5 flex flex-col gap-4" id="tr-form">
        <div class="rounded-xl border ${ds ? 'border-ink-700 bg-ink-900' : 'border-amber-400/30 bg-amber-400/10'} p-3 text-xs">
          <div class="flex items-center justify-between mb-1"><span class="font-bold text-sm">${t('t.dataset')}</span>
            <button class="btn btn-ghost btn-sm" data-go="dataset">${ds ? t('d.title') : t('t.goDataset')}</button></div>
          ${ds ? `<div class="ltr text-ink-400 truncate font-mono text-[11px]">${esc(ds.images_dir)}</div><div class="ltr text-ink-400 truncate font-mono text-[11px]">${esc(ds.masks_dir)}</div>${ds.n_pairs ? `<div class="mt-1 text-mint-300">${fmtNum(ds.n_pairs)} ${t('common.pairs')}</div>` : ''}` : `<span class="text-amber-400">${t('t.noDataset')}</span>`}
        </div>
        <div class="grid grid-cols-[1fr_110px] gap-3">
          ${field(t('t.name'), `<input class="field ltr" data-k="name" value="${esc(c.name)}" />`)}
          ${field(t('t.format'), `<select class="field" data-k="format">${opt('keras', c.format, 'keras')}${opt('h5', c.format, 'h5')}</select>`)}
        </div>
        <div><label class="label">${t('t.arch')}</label><div class="grid grid-cols-2 gap-2">
          ${['simple', 'light', 'standard', 'deep'].map((p) => `<button data-preset="${p}" aria-pressed="${c.preset === p}" class="text-start rounded-xl border p-3 transition ${c.preset === p ? 'border-mint-400 bg-mint-400/10' : 'border-ink-600 bg-ink-900 hover:border-ink-500'}">
            <div class="flex justify-between items-center"><span class="font-bold text-sm">${t('t.preset.' + p)}</span><span class="text-[10px] text-ink-400 ltr">${PRESET_PARAMS[p]}</span></div>
            <div class="text-[11px] text-ink-400 mt-1 leading-5">${t('t.preset.' + p + '.d')}</div></button>`).join('')}</div></div>
        <div><label class="label">${t('t.init')}</label><div class="seg w-full"><button class="flex-1" data-init="new" aria-pressed="${c.init === 'new'}">${t('t.scratch')}</button><button class="flex-1" data-init="active" aria-pressed="${c.init === 'active'}">${t('t.continue')}</button></div></div>
        <div class="grid grid-cols-2 gap-3">
          ${field(t('t.imgSize'), `<select class="field" data-k="image_size" data-num>${[128, 192, 256].map((v) => opt(v, c.image_size, v + '×' + v)).join('')}</select>`)}
          ${field(t('t.epochs'), `<input type="number" min="1" max="500" class="field" data-k="epochs" data-num value="${c.epochs}" />`)}
          ${field(t('t.batch'), `<select class="field" data-k="batch_size" data-num>${[2, 4, 8, 16, 32].map((v) => opt(v, c.batch_size, v)).join('')}</select>`)}
          ${field(t('t.lr'), `<select class="field" data-k="lr" data-num>${[0.01, 0.003, 0.001, 0.0003, 0.0001].map((v) => opt(v, c.lr, v)).join('')}</select>`)}
        </div>
        <div><div class="flex justify-between mb-2"><label class="label !mb-0">${t('t.val')}</label><span id="tr-val-v" class="text-xs font-bold text-mint-300">${Math.round(c.val_split * 100)}%</span></div>
          <input type="range" min="0" max="0.4" step="0.05" value="${c.val_split}" data-k="val_split" data-num /></div>
        ${field(t('t.loss'), `<select class="field" data-k="loss">${opt('bce_dice', c.loss, t('t.loss.bce_dice'))}${opt('bce', c.loss, t('t.loss.bce'))}</select>`)}
        <label class="flex items-center gap-2.5 cursor-pointer text-sm text-ink-200"><input type="checkbox" data-k="augment" ${c.augment ? 'checked' : ''} />${t('t.augment')}</label>
        <p class="text-[11px] text-ink-500 leading-6">${t('t.cpuNote')}</p>
        <div class="flex gap-2"><button class="btn btn-primary flex-1" id="tr-start">${icon('play', 'w-4 h-4')}${t('t.start')}</button>
          <button class="btn btn-danger hidden" id="tr-stop">${icon('stop', 'w-4 h-4')}${t('t.stop')}</button></div>
      </section>
      <section id="tr-monitor" class="flex flex-col gap-4 min-w-0"></section>
    </div>
  </div></div>`;
  root.onclick = trClick;
  root.oninput = trInput;
  root.onchange = trInput;
  trDraw();
}

function trInput(e) {
  const el = e.target.closest('[data-k]');
  if (!el) return;
  const k = el.dataset.k;
  TR.cfg[k] = el.type === 'checkbox' ? el.checked : el.dataset.num !== undefined ? +el.value : el.value;
  if (k === 'val_split') $('#tr-val-v', TR.root).textContent = Math.round(TR.cfg[k] * 100) + '%';
  try { localStorage.setItem('bts.train', JSON.stringify(TR.cfg)); } catch {}
}

async function trClick(e) {
  const pr = e.target.closest('[data-preset]');
  if (pr) { TR.cfg.preset = pr.dataset.preset; trInput({ target: { closest: () => null } }); localStorage.setItem('bts.train', JSON.stringify(TR.cfg)); return trMount(TR.root); }
  const ini = e.target.closest('[data-init]');
  if (ini) { TR.cfg.init = ini.dataset.init; localStorage.setItem('bts.train', JSON.stringify(TR.cfg)); return trMount(TR.root); }
  if (e.target.closest('[data-go]')) return go(e.target.closest('[data-go]').dataset.go);
  if (e.target.closest('#tr-stop')) { await API.call('/train/stop', {}); toast(t('t.stopping')); return; }
  if (e.target.closest('#tr-start')) {
    const ds = trDataset();
    if (!ds) return toast(t('t.noDataset'), 'err');
    try {
      await API.call('/train/start', { ...TR.cfg, images_dir: ds.images_dir, masks_dir: ds.masks_dir });
      TR.st = { status: 'running', phase: 'starting', log: [], history: {} };
      trPoll();
    } catch (err) { toast(err.message, 'err', 6000); }
  }
}

function trPoll() {
  clearTimeout(TR.timer);
  const tick = async () => {
    try { TR.st = await API.call('/train/status'); } catch { /* ignore */ }
    trDraw();
    if (APP.health) APP.health.training = TR.st.status;
    if (trRunning() || (APP.page === 'train')) TR.timer = setTimeout(tick, 1000);
    if (!trRunning() && TR.lastRunning) { TR.lastRunning = false; document.dispatchEvent(new CustomEvent('active-model-changed')); renderSidebar(); }
    TR.lastRunning = trRunning();
  };
  tick();
}

function trDraw() {
  const root = TR.root;
  if (!root) return;
  const st = TR.st, run = trRunning();
  $('#tr-start', root).classList.toggle('hidden', run);
  $('#tr-stop', root).classList.toggle('hidden', !run);
  $$('#tr-form input, #tr-form select, #tr-form [data-preset], #tr-form [data-init]', root).forEach((el) => (el.disabled = run));

  const h = st.history || {};
  const last = (k) => (h[k] && h[k].length ? h[k][h[k].length - 1] : null);
  const live = st.live || {};
  const epochs = st.epochs || TR.cfg.epochs;
  const frac = st.status === 'done' || st.status === 'stopped' ? 1 : st.phase === 'training' && st.batches ? ((st.epoch - 1) + st.batch / st.batches) / epochs : 0;
  const tone = { idle: 'chip', running: 'chip-mint', done: 'chip-mint', stopped: 'chip-amber', error: 'chip-rose' }[st.status] || 'chip';
  const tile = (k, v, c = '') => `<div class="card px-4 py-3"><div class="stat-k">${k}</div><div class="stat-v mt-0.5 ${c}">${v}</div></div>`;
  const best = st.best;
  const chart = (title, series, opts) => `<div class="card p-4"><div class="flex items-center justify-between mb-2"><h4 class="font-bold text-sm">${title}</h4>
    <div class="flex gap-3 text-[11px] text-ink-300">${series.filter((s) => s.data.length).map((s) => `<span class="flex items-center gap-1.5"><i class="w-3 h-0.5 rounded" style="background:${s.color};${s.dash ? 'background:repeating-linear-gradient(90deg,' + s.color + ' 0 4px,transparent 4px 7px)' : ''}"></i>${s.name}</span>`).join('')}</div></div>${lineChart(series, opts)}</div>`;

  $('#tr-monitor', root).innerHTML = `
    <div class="card p-5">
      <div class="flex items-center justify-between mb-3">
        <div class="flex items-center gap-3"><span class="chip ${tone}">${run ? spinner('w-3 h-3') : ''}${t('t.status.' + st.status)}</span>
          ${run && st.phase ? `<span class="text-sm text-ink-300">${t('t.phase.' + st.phase)}${st.phase === 'loading_data' ? ` — ${Math.round((st.load_progress || 0) * 100)}%` : ''}</span>` : ''}</div>
        <span class="text-sm tabular-nums text-ink-300">${st.epoch ? `${t('t.epoch')} ${st.epoch} / ${epochs}` : ''}</span></div>
      <div class="h-2.5 rounded-full bg-ink-900 overflow-hidden border border-ink-700"><div class="h-full bg-gradient-to-l from-mint-300 to-mint-500 rounded-full transition-all duration-500" style="width:${Math.round(frac * 100)}%"></div></div>
      ${st.status === 'error' ? `<div class="mt-3 text-sm text-rose-400 selectable flex gap-2">${icon('alert', 'w-4 h-4 mt-1 shrink-0')}<span>${esc(st.error)}</span></div>` : ''}
      ${st.status === 'done' || st.status === 'stopped' ? `<div class="mt-3 text-sm text-mint-300 flex items-center gap-2">${icon('check', 'w-4 h-4')}${t('t.savedTo')}<span class="ltr text-ink-400 text-xs truncate">${esc(basename(st.out_path))}</span>
        <button class="btn btn-sm ms-auto" data-go="predict">${t('nav.predict')}</button></div>` : ''}
    </div>
    <div class="grid grid-cols-4 gap-3">
      ${tile(t('t.loss.m'), f3(live.loss ?? last('loss')))}${tile(t('t.dice'), f3(live.dice ?? last('dice')))}
      ${tile(t('t.valDice'), f3(last('val_dice')), 'text-amber-400')}${tile(t('t.best'), f3(best), 'text-mint-300')}
    </div>
    <div class="grid grid-cols-2 gap-4">
      ${chart(t('t.chartLoss'), [{ name: t('t.train'), color: 'rgb(var(--mint-500))', data: h.loss || [] }, { name: t('t.validation'), color: 'rgb(var(--amber-400))', dash: true, data: h.val_loss || [] }], { fmt: (v) => v.toFixed(2) })}
      ${chart(t('t.chartDice'), [{ name: t('t.train'), color: 'rgb(var(--mint-500))', data: h.dice || [] }, { name: t('t.validation'), color: 'rgb(var(--amber-400))', dash: true, data: h.val_dice || [] }], { yMin: 0, yMax: 1, fmt: (v) => v.toFixed(1) })}
    </div>
    <div class="card p-4"><h4 class="font-bold text-sm mb-2">${t('t.log')}</h4>
      <pre id="tr-log" class="rounded-xl bg-ink-950 border border-ink-700 p-3 text-[11px] leading-5 text-ink-300 h-44 overflow-auto whitespace-pre-wrap ltr selectable">${esc((st.log || []).join('\n')) || '—'}</pre></div>`;
  const lg = $('#tr-log', root); if (lg) lg.scrollTop = lg.scrollHeight;
}

registerPage('train', {
  mount: trMount,
  show: () => { trMount(TR.root); trPoll(); },
  hide: () => { if (!trRunning()) clearTimeout(TR.timer); },
});
document.addEventListener('dataset-changed', () => { if (TR.root && APP.page !== 'train') trMount(TR.root); });
