/* Theme: 'system' | 'dark' | 'light'. Loaded in <head> to avoid a flash. */
const THEME = {
  mode: 'system',
  mq: window.matchMedia('(prefers-color-scheme: dark)'),
  resolved() { return this.mode === 'system' ? (this.mq.matches ? 'dark' : 'light') : this.mode; },
  apply() { document.documentElement.dataset.theme = this.resolved(); },
  set(m) {
    this.mode = m;
    try { localStorage.setItem('bts.theme', m); } catch {}
    this.apply();
    document.dispatchEvent(new CustomEvent('theme-changed'));
  },
  cycle() { this.set({ system: 'dark', dark: 'light', light: 'system' }[this.mode]); },
  init() {
    try { this.mode = localStorage.getItem('bts.theme') || 'system'; } catch {}
    this.apply();
    this.mq.addEventListener('change', () => { if (this.mode === 'system') { this.apply(); document.dispatchEvent(new CustomEvent('theme-changed')); } });
  },
};
THEME.init();
