/* Dataset page */
const DS = { root: null, images: '', masks: '', result: null, scanning: false, err: null };
try { const s = JSON.parse(localStorage.getItem('bts.dataset') || '{}'); DS.images = s.images || ''; DS.masks = s.masks || ''; } catch {}

function dsSave() { try { localStorage.setItem('bts.dataset', JSON.stringify({ images: DS.images, masks: DS.masks })); } catch {} }

function dsMount(root) {
  DS.root = root;
  const pick = (key, label, val) => `
    <div class="card p-4"><label class="label">${label}</label>
      <div class="flex gap-2"><input readonly class="field ltr font-mono text-xs" value="${esc(val)}" placeholder="${t('d.notPicked')}" />
      <button class="btn" data-pick="${key}">${icon('folder', 'w-4 h-4')}${t('d.pick')}</button></div></div>`;
  const r = DS.result;
  root.innerHTML = `
  <div class="h-full overflow-y-auto"><div class="p-6 max-w-5xl mx-auto flex flex-col gap-5">
    <header><h1 class="text-2xl font-bold">${t('d.title')}</h1><p class="text-sm text-ink-400 mt-1">${t('d.sub')}</p></header>
    <div class="grid grid-cols-2 gap-4">${pick('images', t('d.images'), DS.images)}${pick('masks', t('d.masks'), DS.masks)}</div>
    <div class="flex items-center gap-3">
      <button class="btn btn-primary" data-scan ${DS.images && DS.masks && !DS.scanning ? '' : 'disabled'}>${DS.scanning ? spinner('w-4 h-4') + t('d.scanning') : icon('check', 'w-4 h-4') + t('d.scan')}</button>
      ${DS.err ? `<span class="text-sm text-rose-400 selectable">${esc(DS.err)}</span>` : ''}
    </div>
    ${r ? dsResult(r) : dsHelp()}
  </div></div>`;
  root.onclick = dsClick;
}

function dsHelp() {
  return `<section class="card p-5"><h3 class="font-bold mb-3">${t('d.help.title')}</h3>
    <ul class="text-sm text-ink-300 leading-8 list-disc ps-5">${[1, 2, 3, 4].map((i) => `<li>${t('d.help.' + i)}</li>`).join('')}</ul></section>`;
}

function dsResult(r) {
  const tile = (k, v, tone = '') => `<div class="card p-4"><div class="stat-k">${k}</div><div class="stat-v mt-1 ${tone}">${v}</div></div>`;
  const bad = r.n_pairs === 0;
  const warnTone = (w) => (['no_pairs', 'few_pairs'].includes(w) ? 'rose' : ['unmatched_images', 'imbalance', 'many_empty'].includes(w) ? 'amber' : 'sky');
  const tones = { rose: 'border-rose-500/30 bg-rose-500/10 text-rose-400', amber: 'border-amber-400/30 bg-amber-400/10 text-amber-400', sky: 'border-sky-400/30 bg-sky-400/10 text-sky-400' };
  return `
    <div class="grid grid-cols-4 gap-4">
      ${tile(t('d.nImages'), fmtNum(r.n_images))}${tile(t('d.nMasks'), fmtNum(r.n_masks))}
      ${tile(t('d.nPairs'), fmtNum(r.n_pairs), bad ? 'text-rose-400' : 'text-mint-300')}${tile(t('d.fraction'), pct(r.mean_mask_fraction, 2))}
    </div>
    ${r.warnings.length ? `<div class="flex flex-col gap-2">${r.warnings.map((w) => `<div class="flex items-start gap-3 rounded-xl border px-4 py-3 text-sm leading-7 ${tones[warnTone(w)]}">${icon(warnTone(w) === 'sky' ? 'info' : 'alert', 'w-4 h-4 mt-1.5 shrink-0')}<span>${t('d.warn.' + w)}</span></div>`).join('')}</div>` : ''}
    <div class="grid grid-cols-3 gap-4 text-sm">
      <div class="card p-4"><div class="stat-k">${t('d.maskKind')}</div><div class="mt-1 font-medium">${r.mask_kind ? t('d.kind.' + r.mask_kind) : '—'}</div></div>
      <div class="card p-4"><div class="stat-k">${t('d.sizes')}</div><div class="mt-1 font-medium ltr">${r.sizes.map(([k, n]) => `${k} <span class="text-ink-500">(${n})</span>`).join('  ·  ') || '—'}</div></div>
      <div class="card p-4"><div class="stat-k">${t('d.emptyFrac')}</div><div class="mt-1 font-medium">${pct(r.empty_fraction, 0)}</div></div>
    </div>
    ${r.samples.length ? `<section><div class="flex items-baseline gap-3 mb-3"><h3 class="font-bold">${t('d.samples')}</h3><span class="text-xs text-ink-500">${t('d.sampleHint')}</span></div>
      <div class="grid grid-cols-4 gap-3">${r.samples.map((s) => `<div class="card overflow-hidden"><div class="grid grid-cols-2 gap-px bg-ink-700">
        <img class="w-full aspect-square object-cover" src="${API.thumb(s.image, 200)}" loading="lazy" alt="" />
        <img class="w-full aspect-square object-cover" src="${API.thumb(s.image, 200, s.mask)}" loading="lazy" alt="" /></div>
        <div class="px-2.5 py-2 text-[11px] text-ink-400 ltr truncate">${esc(basename(s.image))}</div></div>`).join('')}</div></section>` : ''}
    ${r.unmatched_images.length || r.unmatched_masks.length ? `<details class="card px-4 py-3 text-xs text-ink-300"><summary class="cursor-pointer">${t('d.unmatched')} (${r.n_images - r.n_pairs} / ${r.n_masks - r.n_pairs})</summary>
      <div class="mt-3 ltr font-mono text-[11px] leading-6 text-ink-400 selectable">${[...r.unmatched_images, ...r.unmatched_masks].map((p) => esc(p)).join('<br>')}</div></details>` : ''}
    ${r.n_pairs ? `<div><button class="btn btn-primary" data-go="train">${t('d.toTrain')}${icon('chevron', 'w-4 h-4 rtl:rotate-180')}</button></div>` : ''}`;
}

async function dsClick(e) {
  const p = e.target.closest('[data-pick]');
  if (p) {
    const dir = await native.pickFolder(t('d.pick'));
    if (dir) { DS[p.dataset.pick] = dir; DS.result = null; DS.err = null; dsSave(); dsMount(DS.root); }
    return;
  }
  if (e.target.closest('[data-go]')) return go('train');
  if (e.target.closest('[data-scan]')) {
    DS.scanning = true; DS.err = null; dsMount(DS.root);
    try { DS.result = await API.call('/dataset/scan', { images_dir: DS.images, masks_dir: DS.masks }); document.dispatchEvent(new CustomEvent('dataset-changed')); }
    catch (err) { DS.err = err.message; DS.result = null; }
    DS.scanning = false; dsMount(DS.root);
  }
}

registerPage('dataset', { mount: dsMount });
