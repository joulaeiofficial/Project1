/* Small UI helpers shared by all pages */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const basename = (p) => String(p || '').split(/[\\/]/).pop();
const stem = (p) => basename(p).replace(/\.[^.]+$/, '');
const debounce = (fn, ms) => { let h; return (...a) => { clearTimeout(h); h = setTimeout(() => fn(...a), ms); }; };
const fmtBytes = (n) => (n > 1e9 ? (n / 1e9).toFixed(2) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : n > 1e3 ? (n / 1e3).toFixed(0) + ' KB' : n + ' B');
const fmtNum = (n) => (n == null ? '—' : Number(n).toLocaleString('en-US'));
const fmtParams = (n) => (n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(0) + 'K' : String(n));
const pct = (x, d = 1) => (x == null || isNaN(x) ? '—' : (x * 100).toFixed(d) + '%');
const f3 = (x) => (x == null || isNaN(x) ? '—' : Number(x).toFixed(3));

const ICONS = {
  predict: '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3.2"/>',
  dataset: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
  models: '<path d="M12 3 3 8l9 5 9-5-9-5Z"/><path d="m3 13 9 5 9-5"/><path d="m3 17.5 9 5 9-5" opacity=".5"/>',
  train: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  settings: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  upload: '<path d="M12 16V4m0 0L8 8m4-4 4 4M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
  download: '<path d="M12 4v12m0 0-4-4m4 4 4-4M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  alert: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4m0 3h.01"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
  play: '<path d="m7 4 13 8-13 8V4Z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.5 3.5 5.5 3.5 9s-1 6.5-3.5 9c-2.5-2.5-3.5-5.5-3.5-9s1-6.5 3.5-9Z"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  chevron: '<path d="m9 6 6 6-6 6"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  layers: '<path d="M12 3 3 8l9 5 9-5-9-5Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5Z"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  terminal: '<path d="m5 8 5 4-5 4M12 17h7"/>',
};
function icon(name, cls = 'w-5 h-5') {
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}
const spinner = (cls = 'w-5 h-5') => `<svg class="${cls} animate-spin" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-opacity=".2" stroke-width="3"/><path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>`;

function toast(msg, type = 'info', ms = 3600) {
  const root = $('#toast-root');
  const tone = { info: 'border-ink-600 text-ink-100', ok: 'border-mint-400/40 text-mint-300', err: 'border-rose-500/50 text-rose-400' }[type];
  const ic = { info: 'info', ok: 'check', err: 'alert' }[type];
  const el = document.createElement('div');
  el.className = `animate-fadeUp flex items-center gap-2.5 max-w-md rounded-xl border bg-ink-800/95 backdrop-blur px-4 py-3 text-sm shadow-xl ${tone}`;
  el.innerHTML = `${icon(ic, 'w-4 h-4 shrink-0')}<span class="selectable">${esc(msg)}</span>`;
  root.appendChild(el);
  setTimeout(() => { el.style.transition = 'opacity .3s'; el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, ms);
}

function modal({ title, body, actions = [], width = 'max-w-lg' }) {
  const wrap = document.createElement('div');
  wrap.className = 'fixed inset-0 z-50 flex items-center justify-center p-6 bg-ink-950/70 backdrop-blur-sm animate-fadeUp';
  wrap.innerHTML = `<div class="card w-full ${width} p-6 shadow-2xl" role="dialog" aria-modal="true">
    <h3 class="text-lg font-bold mb-3">${esc(title)}</h3><div data-body class="text-sm text-ink-200"></div>
    <div data-actions class="flex gap-2 justify-end mt-6"></div></div>`;
  const b = $('[data-body]', wrap);
  if (typeof body === 'string') b.innerHTML = body; else if (body) b.appendChild(body);
  const close = () => wrap.remove();
  actions.forEach((a) => {
    const btn = document.createElement('button');
    btn.className = `btn ${a.cls || ''}`;
    btn.innerHTML = a.label;
    btn.onclick = async () => { const r = a.onClick ? await a.onClick(wrap) : undefined; if (r !== false && !a.keepOpen) close(); };
    $('[data-actions]', wrap).appendChild(btn);
  });
  wrap.addEventListener('mousedown', (e) => { if (e.target === wrap) close(); });
  document.body.appendChild(wrap);
  return { el: wrap, close };
}

/* Minimal SVG line chart. series: [{name,color,dash,data:[..]}] */
function lineChart(series, { w = 440, h = 190, yMin = null, yMax = null, fmt = (v) => v.toFixed(2) } = {}) {
  const all = series.flatMap((s) => s.data).filter((v) => v != null && isFinite(v));
  if (!all.length) return `<div class="h-[${h}px] grid place-items-center text-xs text-ink-500">—</div>`;
  const n = Math.max(...series.map((s) => s.data.length));
  let lo = yMin ?? Math.min(...all), hi = yMax ?? Math.max(...all);
  if (hi - lo < 1e-6) { hi += 0.5; lo -= 0.5; }
  const pad = { l: 38, r: 10, t: 10, b: 22 };
  const iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
  const X = (i) => pad.l + (n <= 1 ? iw / 2 : (i / (n - 1)) * iw);
  const Y = (v) => pad.t + ih - ((v - lo) / (hi - lo)) * ih;
  let g = '';
  for (let k = 0; k <= 3; k++) {
    const v = lo + ((hi - lo) * k) / 3, y = Y(v);
    g += `<line x1="${pad.l}" x2="${w - pad.r}" y1="${y}" y2="${y}" stroke="rgb(var(--ink-700))" stroke-width="1"/><text x="${pad.l - 6}" y="${y + 3}" text-anchor="end" font-size="9.5" fill="rgb(var(--ink-400))">${fmt(v)}</text>`;
  }
  const step = Math.max(1, Math.ceil(n / 8));
  for (let i = 0; i < n; i += step) g += `<text x="${X(i)}" y="${h - 6}" text-anchor="middle" font-size="9.5" fill="rgb(var(--ink-400))">${i + 1}</text>`;
  let lines = '';
  series.forEach((s) => {
    const pts = s.data.map((v, i) => (v == null ? null : [X(i), Y(v)])).filter(Boolean);
    if (!pts.length) return;
    lines += `<polyline fill="none" stroke="${s.color}" stroke-width="2" ${s.dash ? 'stroke-dasharray="5 4"' : ''} stroke-linejoin="round" stroke-linecap="round" points="${pts.map((p) => p.join(',')).join(' ')}"/>`;
    const last = pts[pts.length - 1];
    lines += `<circle cx="${last[0]}" cy="${last[1]}" r="3.2" fill="${s.color}"/>`;
  });
  return `<svg viewBox="0 0 ${w} ${h}" class="w-full h-auto" dir="ltr" role="img">${g}${lines}</svg>`;
}

/* Reusable field blocks */
const pathField = (id, value, placeholder) => `<input id="${id}" readonly class="field ltr font-mono text-xs" value="${esc(value || '')}" placeholder="${esc(placeholder || '')}" />`;
