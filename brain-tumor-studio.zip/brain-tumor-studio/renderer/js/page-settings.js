/* Settings page */
const ST = { root: null, info: null, settings: {} };

async function stLoad() {
  ST.settings = await native.getSettings().catch(() => ({}));
  ST.info = await native.appInfo().catch(() => null);
  stMount(ST.root);
}

function stMount(root) {
  ST.root = root;
  const h = APP.health || {};
  const kv = (k, v) => `<div class="flex justify-between py-2.5 border-b border-ink-700/60 last:border-0 text-sm"><span class="text-ink-400">${k}</span><span class="ltr font-medium text-ink-100 selectable">${esc(v || '—')}</span></div>`;
  root.innerHTML = `
  <div class="h-full overflow-y-auto"><div class="p-6 max-w-3xl mx-auto flex flex-col gap-5">
    <header><h1 class="text-2xl font-bold">${t('s.title')}</h1><p class="text-sm text-ink-400 mt-1">${t('s.sub')}</p></header>
    <section class="card p-5">
      <h3 class="font-bold mb-3">${t('s.engine')}</h3>
      ${kv(t('s.ver.python'), h.python ? `${h.python}  (${APP.backend.python || ''})` : '')}${kv(t('s.ver.tf'), h.tf && h.tf.version)}${kv(t('s.ver.cv'), h.cv2)}${kv(t('s.ver.electron'), ST.info && ST.info.electron)}
      <div class="mt-4"><label class="label">${t('s.python')}</label>
        <div class="flex gap-2"><input id="st-py" class="field ltr font-mono text-xs" value="${esc(ST.settings.pythonPath || '')}" placeholder="auto" />
          <button class="btn" id="st-browse">${icon('folder', 'w-4 h-4')}</button><button class="btn" id="st-apply">${icon('refresh', 'w-4 h-4')}${t('s.apply')}</button></div>
        <p class="text-[11px] text-ink-500 mt-1.5">${t('s.pythonHint')}</p></div>
      <div class="mt-5 pt-4 border-t border-ink-700/60"><button class="btn" id="set-install">${icon('download', 'w-4 h-4')}${t('s.install')}</button>
        <p class="text-[11px] text-ink-500 mt-2 leading-6">${t('s.installHint')}</p></div>
    </section>
    <section class="card p-5"><h3 class="font-bold mb-3">${t('s.theme')}</h3>
      <div class="seg">${['system', 'dark', 'light'].map((m) => `<button data-theme-set="${m}" aria-pressed="${THEME.mode === m}" class="inline-flex items-center gap-1.5">${icon({ system: 'monitor', dark: 'moon', light: 'sun' }[m], 'w-3.5 h-3.5')}${t('theme.' + m)}</button>`).join('')}</div></section>
    <section class="card p-5"><h3 class="font-bold mb-3">${t('s.lang')}</h3>
      <div class="seg"><button data-lang-set="fa" aria-pressed="${I18N.lang === 'fa'}">فارسی</button><button data-lang-set="en" aria-pressed="${I18N.lang === 'en'}">English</button></div></section>
    <section class="card p-5"><h3 class="font-bold mb-3">${t('s.about')}</h3>
      ${kv(t('s.data'), h.data_dir)}${kv('Version', ST.info && ST.info.version)}
      <p class="text-xs text-ink-500 mt-3 leading-6">${t('disclaimer')}</p></section>
  </div></div>`;
  $('#st-browse', root).onclick = async () => { const p = await native.pickPython(); if (p) $('#st-py', root).value = p; };
  $('#st-apply', root).onclick = async () => {
    await native.setSettings({ pythonPath: $('#st-py', root).value.trim() });
    await native.restartBackend();
  };
  $('#set-install', root).onclick = async () => { await runInstall(); stLoad(); };
  $$('[data-theme-set]', root).forEach((b) => (b.onclick = () => THEME.set(b.dataset.themeSet)));
  $$('[data-lang-set]', root).forEach((b) => (b.onclick = () => { if (b.dataset.langSet !== I18N.lang) switchLang(); }));
}

registerPage('settings', { mount: stMount, show: stLoad });
