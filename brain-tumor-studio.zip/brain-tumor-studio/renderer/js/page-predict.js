/* Predict page */
const PR = {
  root: null,
  items: [],
  index: -1,
  view: 'overlay',
  seq: 0,
  p: { threshold: 0.5, minArea: 0, opacity: 0.45, fill: true, contour: true, circle: true },
};
const IMG_RE = /\.(png|jpe?g|bmp|tiff?|webp)$/i;

const prBody = () => ({ threshold: PR.p.threshold, min_area: PR.p.minArea, opacity: PR.p.opacity, fill: PR.p.fill, contour: PR.p.contour, circle: PR.p.circle });
const prKey = () => JSON.stringify(prBody());
const prCur = () => PR.items[PR.index];

function prMount(root) {
  PR.root = root;
  const slider = (id, label, min, max, step, val, fmt) => `
    <div><div class="flex justify-between items-center mb-2"><label class="label !mb-0" for="${id}">${label}</label><span id="${id}-v" class="text-xs font-bold tabular-nums text-mint-300">${fmt(val)}</span></div>
    <input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${val}" /></div>`;
  const check = (id, label, dot, on) => `<label class="flex items-center gap-2.5 h-8 cursor-pointer text-sm text-ink-200"><input type="checkbox" id="${id}" ${on ? 'checked' : ''} /><span class="w-2.5 h-2.5 rounded-full" style="background:${dot}"></span>${label}</label>`;

  root.innerHTML = `
  <div class="h-full flex flex-col p-6 gap-4 relative" id="pr-page">
    <header class="flex items-center justify-between gap-4 shrink-0">
      <div><h1 class="text-2xl font-bold">${t('p.title')}</h1><p class="text-sm text-ink-400 mt-1">${t('p.sub')}</p></div>
      <div class="flex gap-2">
        <button class="btn" data-act="addFiles">${icon('image', 'w-4 h-4')}${t('p.addFiles')}</button>
        <button class="btn" data-act="addFolder">${icon('folder', 'w-4 h-4')}${t('p.addFolder')}</button>
        <button class="btn btn-primary" data-act="exportOne" data-need-item>${icon('download', 'w-4 h-4')}${t('p.exportOne')}</button>
        <button class="btn" data-act="exportAll" data-need-item>${t('p.exportAll')}</button>
      </div>
    </header>
    <div id="pr-banner" class="shrink-0"></div>

    <div id="pr-empty" class="flex-1 min-h-0 grid place-items-center rounded-3xl border-2 border-dashed border-ink-600 bg-ink-900/40 transition">
      <div class="text-center max-w-sm px-6">
        <div class="mx-auto w-16 h-16 rounded-2xl grid place-items-center bg-mint-400/10 text-mint-300 ring-1 ring-mint-400/25 mb-5">${icon('upload', 'w-7 h-7')}</div>
        <div class="text-lg font-bold">${t('p.dropTitle')}</div>
        <p class="text-sm text-ink-400 mt-2 leading-7">${t('p.dropSub')}</p>
        <div class="flex gap-2 justify-center mt-6">
          <button class="btn btn-primary" data-act="addFiles">${icon('image', 'w-4 h-4')}${t('p.addFiles')}</button>
          <button class="btn" data-act="addFolder">${icon('folder', 'w-4 h-4')}${t('p.addFolder')}</button>
        </div>
      </div>
    </div>

    <div id="pr-main" class="hidden flex-1 min-h-0 grid grid-cols-[minmax(0,1fr)_304px] gap-5">
      <div class="min-h-0 flex flex-col gap-3">
        <div class="flex-1 min-h-0 grid grid-cols-[minmax(0,2fr)_minmax(0,1fr)] grid-rows-2 gap-3">
          <figure class="card checker relative overflow-hidden row-span-2" id="pr-result">
            <figcaption class="absolute top-3 start-3 z-10"><div class="seg backdrop-blur" id="pr-seg">
              <button data-view="overlay" aria-pressed="true">${t('p.overlay')}</button><button data-view="heat" aria-pressed="false">${t('p.heat')}</button></div></figcaption>
            <img id="pr-img-result" class="absolute inset-0 w-full h-full object-contain p-3 hidden" alt="" />
            <div id="pr-loading" class="absolute inset-0 grid place-items-center text-ink-300 hidden"><div class="flex flex-col items-center gap-3">${spinner('w-7 h-7 text-mint-400')}<span class="text-sm">${t('p.running')}</span></div></div>
            <div id="pr-error" class="absolute inset-0 grid place-items-center p-8 text-center hidden"></div>
            <div class="absolute bottom-3 start-3 z-10 flex gap-1.5 flex-wrap" id="pr-legend">
              <span class="chip"><i class="w-2 h-2 rounded-full" style="background:#ff465a"></i>${t('p.fill')}</span>
              <span class="chip"><i class="w-2 h-2 rounded-full" style="background:#ffcd00"></i>${t('p.contour')}</span>
              <span class="chip"><i class="w-2 h-2 rounded-full" style="background:#28beff"></i>${t('p.circle')}</span></div>
          </figure>
          <figure class="card checker relative overflow-hidden"><figcaption class="absolute top-3 start-3 z-10 chip backdrop-blur">${t('p.original')}</figcaption>
            <img id="pr-img-orig" class="absolute inset-0 w-full h-full object-contain p-3 pt-10 hidden" alt="" /></figure>
          <figure class="card checker relative overflow-hidden"><figcaption class="absolute top-3 start-3 z-10 chip backdrop-blur">${t('p.mask')}</figcaption>
            <img id="pr-img-mask" class="absolute inset-0 w-full h-full object-contain p-3 pt-10 hidden" style="image-rendering:pixelated" alt="" /></figure>
        </div>
        <div class="shrink-0">
          <div class="flex items-center justify-between mb-2 px-1"><span class="text-xs text-ink-400"><span id="pr-qcount"></span> · ${t('p.queue')}</span>
            <button class="btn btn-ghost btn-sm" data-act="clear">${icon('trash', 'w-3.5 h-3.5')}${t('p.clear')}</button></div>
          <div id="pr-queue" class="flex gap-2 overflow-x-auto pb-2"></div>
        </div>
      </div>

      <aside class="min-h-0 overflow-y-auto flex flex-col gap-4 pe-1">
        <section class="card p-4 flex flex-col gap-4">
          <div class="flex items-center justify-between"><h3 class="font-bold text-sm">${t('p.controls')}</h3>
            <button class="btn btn-ghost btn-sm" data-act="resetP">${icon('refresh', 'w-3.5 h-3.5')}${t('p.reset')}</button></div>
          ${slider('pr-th', t('p.threshold'), 0.05, 0.95, 0.01, PR.p.threshold, (v) => (+v).toFixed(2))}
          ${slider('pr-min', t('p.minArea'), 0, 3, 0.05, PR.p.minArea, (v) => (+v).toFixed(2) + '%')}
          ${slider('pr-op', t('p.opacity'), 0.1, 0.9, 0.05, PR.p.opacity, (v) => Math.round(v * 100) + '%')}
          <div class="border-t border-ink-700 pt-3">
            ${check('pr-fill', t('p.fill'), '#ff465a', PR.p.fill)}${check('pr-contour', t('p.contour'), '#ffcd00', PR.p.contour)}${check('pr-circle', t('p.circle'), '#28beff', PR.p.circle)}
          </div>
        </section>
        <section class="card p-4" id="pr-stats"></section>
      </aside>
    </div>
  </div>`;

  const bind = (id, key, num) => {
    const el = $('#' + id, root);
    el.addEventListener('input', () => {
      PR.p[key] = num ? +el.value : el.checked;
      if (num) $('#' + id + '-v', root).textContent = { threshold: (+el.value).toFixed(2), minArea: (+el.value).toFixed(2) + '%', opacity: Math.round(el.value * 100) + '%' }[key];
      prRerender();
    });
  };
  bind('pr-th', 'threshold', true); bind('pr-min', 'minArea', true); bind('pr-op', 'opacity', true);
  bind('pr-fill', 'fill'); bind('pr-contour', 'contour'); bind('pr-circle', 'circle');

  root.addEventListener('click', prClick);
  // drag & drop
  const page = $('#pr-page', root);
  page.addEventListener('dragover', (e) => { e.preventDefault(); $('#pr-empty', root).classList.add('border-mint-400', 'bg-mint-400/5'); });
  page.addEventListener('dragleave', (e) => { if (e.target === page || e.target.id === 'pr-empty') $('#pr-empty', root).classList.remove('border-mint-400', 'bg-mint-400/5'); });
  page.addEventListener('drop', async (e) => {
    e.preventDefault();
    $('#pr-empty', root).classList.remove('border-mint-400', 'bg-mint-400/5');
    const paths = [];
    for (const f of e.dataTransfer.files) {
      const p = native.pathForFile(f);
      if (IMG_RE.test(p)) paths.push(p);
      else { try { const r = await API.call('/fs/images', { dir: p }); paths.push(...r.files); } catch { /* not a folder */ } }
    }
    prAdd(paths);
  });
  prDrawAll();
}

async function prClick(e) {
  const seg = e.target.closest('[data-view]');
  if (seg) { PR.view = seg.dataset.view; prDrawViewer(); return; }
  const q = e.target.closest('[data-q]');
  if (q) return prSelect(+q.dataset.q);
  const a = e.target.closest('[data-act]');
  if (!a) return;
  switch (a.dataset.act) {
    case 'addFiles': prAdd(await native.pickImages()); break;
    case 'addFolder': {
      const dir = await native.pickFolder(t('p.addFolder'));
      if (!dir) break;
      try { const r = await API.call('/fs/images', { dir }); prAdd(r.files); } catch (err) { toast(err.message, 'err'); }
      break;
    }
    case 'clear': PR.items = []; PR.index = -1; prDrawAll(); break;
    case 'resetP':
      PR.p = { threshold: 0.5, minArea: 0, opacity: 0.45, fill: true, contour: true, circle: true };
      prMount(PR.root); break;
    case 'exportOne': prExport(false); break;
    case 'exportAll': prExport(true); break;
    case 'goModels': go('models'); break;
  }
}

async function prAdd(paths) {
  paths = (paths || []).filter((p) => !PR.items.some((i) => i.path === p));
  if (!paths.length) return;
  const first = PR.items.length;
  paths.forEach((p) => PR.items.push({ path: p, name: basename(p), status: 'idle', result: null }));
  prSelect(PR.index >= 0 && PR.items.length > paths.length ? PR.index : first);
}

async function prSelect(i) {
  PR.index = i;
  prDrawAll();
  const it = prCur();
  if (!it) return;
  if (!it.result) await prEnsure(it);
  else if (it.result.key !== prKey()) prRerender();
}

async function prEnsure(it) {
  if (it.result || it.status === 'loading') return;
  it.status = 'loading'; it.error = null;
  if (prCur() === it) prDrawAll();
  const key = prKey();
  try {
    const r = await API.call('/predict', { path: it.path, ...prBody() });
    r.key = key;
    it.result = r; it.status = 'done';
  } catch (err) {
    it.status = 'error'; it.error = err.message;
  }
  if (prCur() === it) { prDrawAll(); if (it.result && it.result.key !== prKey()) prRerender(); }
  else prDrawQueue();
}

const prRerender = debounce(async () => {
  const it = prCur();
  if (!it || !it.result) return;
  const my = ++PR.seq;
  const key = prKey();
  try {
    const r = await API.call('/render', { id: it.result.id, ...prBody() });
    if (my !== PR.seq) return;
    Object.assign(it.result, r, { key });
    prDrawViewer(); prDrawStats();
  } catch (err) {
    if (err.code === 'expired') { it.result = null; it.status = 'idle'; prEnsure(it); }
  }
}, 60);

/* ------------------------------------------------------------ drawing */
function prDrawAll() {
  const root = PR.root;
  const has = PR.items.length > 0;
  $('#pr-empty', root).classList.toggle('hidden', has);
  $('#pr-main', root).classList.toggle('hidden', !has);
  $$('[data-need-item]', root).forEach((b) => (b.disabled = !has));
  prDrawBanner(); prDrawQueue(); prDrawViewer(); prDrawStats();
}

function prDrawBanner() {
  const el = $('#pr-banner', PR.root);
  if (!el) return;
  const noModel = APP.health && APP.health.tf && APP.health.tf.state === 'ready' && !APP.health.active;
  el.innerHTML = noModel ? `<div class="flex items-center gap-3 rounded-xl border border-amber-400/30 bg-amber-400/10 text-amber-400 px-4 py-2.5 text-sm">${icon('alert', 'w-4 h-4')}<span>${t('p.noModel')}</span><button class="btn btn-sm ms-auto" data-act="goModels">${t('p.goModels')}</button></div>` : '';
}

function prDrawQueue() {
  const root = PR.root;
  $('#pr-qcount', root).textContent = `${PR.index + 1} / ${PR.items.length}`;
  $('#pr-queue', root).innerHTML = PR.items.map((it, i) => {
    const sel = i === PR.index;
    const badge = it.status === 'done' ? `<span class="absolute bottom-1 end-1 w-4 h-4 rounded-full grid place-items-center ${it.result && it.result.stats.regions ? 'bg-rose-500' : 'bg-mint-400'} text-white">${icon(it.result && it.result.stats.regions ? 'alert' : 'check', 'w-2.5 h-2.5')}</span>`
      : it.status === 'error' ? `<span class="absolute bottom-1 end-1 w-4 h-4 rounded-full grid place-items-center bg-ink-950 text-rose-400">${icon('x', 'w-2.5 h-2.5')}</span>`
      : it.status === 'loading' ? `<span class="absolute bottom-1 end-1 text-mint-300">${spinner('w-4 h-4')}</span>` : '';
    return `<button data-q="${i}" title="${esc(it.name)}" class="relative shrink-0 w-[68px] h-[68px] rounded-xl overflow-hidden border-2 transition ${sel ? 'border-mint-400 shadow-glow' : 'border-ink-700 hover:border-ink-500 opacity-80 hover:opacity-100'}">
      <img src="${API.thumb(it.path, 96)}" loading="lazy" class="w-full h-full object-cover" alt="" />${badge}</button>`;
  }).join('');
  const sel = $('#pr-queue [data-q="' + PR.index + '"]', root);
  if (sel) sel.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

function prDrawViewer() {
  const root = PR.root;
  const it = prCur();
  const res = it && it.result;
  const set = (id, src) => { const el = $(id, root); if (src) { el.src = src; el.classList.remove('hidden'); } else el.classList.add('hidden'); };
  set('#pr-img-result', res && (PR.view === 'heat' ? res.heat : res.overlay));
  set('#pr-img-orig', res && res.original);
  set('#pr-img-mask', res && res.mask);
  $('#pr-loading', root).classList.toggle('hidden', !(it && it.status === 'loading'));
  const err = $('#pr-error', root);
  if (it && it.status === 'error') {
    err.classList.remove('hidden');
    err.innerHTML = `<div class="max-w-sm"><div class="mx-auto w-12 h-12 rounded-xl grid place-items-center bg-rose-500/10 text-rose-400 mb-3">${icon('alert', 'w-6 h-6')}</div><div class="font-bold mb-1">${t('p.failed')}</div><div class="text-xs text-ink-400 break-words selectable leading-6">${esc(it.error)}</div>
      <button class="btn btn-sm mt-4" data-act="retry">${t('common.retry')}</button></div>`;
    $('[data-act=retry]', err).onclick = () => { it.status = 'idle'; it.result = null; prEnsure(it); };
  } else err.classList.add('hidden');
  $$('#pr-seg button', root).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.view === PR.view)));
  $('#pr-legend', root).classList.toggle('hidden', PR.view !== 'overlay');
}

function prDrawStats() {
  const el = $('#pr-stats', PR.root);
  const it = prCur();
  const r = it && it.result;
  if (!r) { el.innerHTML = `<h3 class="font-bold text-sm mb-3">${t('p.stats')}</h3><div class="text-xs text-ink-500">${it && it.status === 'loading' ? t('p.running') : '—'}</div>`; return; }
  const s = r.stats;
  const found = s.regions > 0;
  const tile = (k, v) => `<div class="rounded-xl bg-ink-900 border border-ink-700/70 px-3 py-2.5"><div class="stat-k">${k}</div><div class="stat-v mt-0.5">${v}</div></div>`;
  el.innerHTML = `
    <h3 class="font-bold text-sm mb-3">${t('p.stats')}</h3>
    <div class="flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium mb-3 ${found ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' : 'bg-mint-400/10 text-mint-300 border border-mint-400/30'}">
      ${icon(found ? 'alert' : 'check', 'w-4 h-4 shrink-0')}<span>${found ? t('p.found') : t('p.notFound')}</span></div>
    <div class="grid grid-cols-2 gap-2">
      ${tile(t('p.area'), s.area_pct.toFixed(2) + '<span class="text-xs font-medium text-ink-400">%</span>')}
      ${tile(t('p.regions'), s.regions)}
      ${tile(t('p.maxProb'), pct(s.max_prob, 0))}
      ${tile(t('p.meanConf'), found ? pct(s.mean_conf, 0) : '—')}
      ${tile(t('p.time'), r.ms + '<span class="text-xs font-medium text-ink-400"> ms</span>')}
      ${tile(t('p.size'), `<span class="text-base ltr inline-block">${r.width}×${r.height}</span>`)}
    </div>
    ${s.region_list.length ? `<div class="mt-4"><div class="stat-k mb-2">${t('p.regionList')}</div><div class="flex flex-col gap-1.5">
      ${s.region_list.slice(0, 5).map((g, i) => `<div class="flex items-center gap-2 text-xs rounded-lg bg-ink-900 border border-ink-700/60 px-2.5 py-2"><span class="w-5 h-5 rounded-md grid place-items-center bg-rose-500/15 text-rose-400 font-bold text-[10px]">${i + 1}</span>
        <span class="tabular-nums text-ink-200">${g.area_pct.toFixed(2)}%</span><span class="text-ink-500 tabular-nums">${fmtNum(g.area_px)} px</span><span class="ms-auto tabular-nums text-mint-300">${pct(g.confidence, 0)}</span></div>`).join('')}
    </div></div>` : ''}
    <div class="mt-4 text-[11px] text-ink-500 ltr truncate" title="${esc(it.path)}">${esc(it.name)}</div>`;
}

/* ------------------------------------------------------------ export */
async function prExport(all) {
  const dir = await native.pickFolder(t('p.pickOut'));
  if (!dir) return;
  const list = all ? PR.items : [prCur()];
  const used = new Set();
  let done = 0;
  toast(t('p.exporting'));
  for (const it of list) {
    try {
      if (!it.result) await prEnsure(it);
      if (!it.result) continue;
      const full = await API.call('/render', { id: it.result.id, ...prBody(), full: true });
      let base = stem(it.name);
      if (used.has(base)) { let n = 2; while (used.has(`${base}_${n}`)) n++; base = `${base}_${n}`; }
      used.add(base);
      await native.writeDataUri(await native.join(dir, `${base}_overlay.png`), full.overlay);
      await native.writeDataUri(await native.join(dir, `${base}_mask.png`), full.mask);
      done++;
    } catch (err) { toast(`${it.name}: ${err.message}`, 'err'); }
  }
  toast(`${t('p.saved')} — ${done}`, 'ok');
  native.openFolder(dir);
}

registerPage('predict', {
  mount: prMount,
  show: () => prDrawBanner(),
});
document.addEventListener('active-model-changed', () => { if (PR.root) prDrawBanner(); });
