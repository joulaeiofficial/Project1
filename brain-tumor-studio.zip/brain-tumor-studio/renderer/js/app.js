/* App core: backend connection, sidebar, router, setup overlay */
const APP = {
  backend: { state: 'starting' },
  health: null,
  page: 'predict',
  pages: {},
  roots: {},
  installing: false,
};

const API = {
  url(path, params = {}) {
    const q = new URLSearchParams({ ...params, token: APP.backend.token });
    return `http://127.0.0.1:${APP.backend.port}${path}?${q}`;
  },
  async call(path, body, method) {
    if (APP.backend.state !== 'ready') throw Object.assign(new Error('Backend not ready'), { code: 'not_ready' });
    const opts = { method: method || (body ? 'POST' : 'GET'), headers: { 'X-Token': APP.backend.token } };
    if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(`http://127.0.0.1:${APP.backend.port}${path}`, opts); }
    catch (e) { throw Object.assign(new Error('Cannot reach the Python engine'), { code: 'unreachable' }); }
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data.error || `HTTP ${r.status}`), { code: data.code || 'http', status: r.status });
    return data;
  },
  thumb: (path, size = 200, mask) => API.url('/thumb', { path, size, ...(mask ? { mask } : {}) }),
};

const NAV = [
  ['predict', 'predict'], ['dataset', 'dataset'], ['models', 'models'], ['train', 'train'], ['settings', 'settings'],
];

/* ------------------------------------------------------------ sidebar */
function renderSidebar() {
  const h = APP.health;
  const active = h && h.active ? stem(h.active) : null;
  const tf = h && h.tf ? h.tf.state : null;
  let engine = { cls: 'bg-amber-400', txt: t('side.loading') };
  if (APP.backend.state === 'error' || tf === 'error') engine = { cls: 'bg-rose-500', txt: t('side.error') };
  else if (APP.backend.state === 'ready' && tf === 'ready') engine = { cls: 'bg-mint-400', txt: t('side.ready') };
  const training = h && h.training === 'running';

  $('#sidebar').innerHTML = `
    <div class="flex items-center gap-3 px-1">
      <div class="w-10 h-10 rounded-xl grid place-items-center bg-mint-400/10 text-mint-300 ring-1 ring-mint-400/30 shadow-glow">${icon('predict', 'w-5 h-5')}</div>
      <div class="min-w-0"><div class="font-bold leading-tight truncate">${t('app')}</div><div class="text-[11px] text-ink-400 leading-tight mt-0.5">${t('tagline')}</div></div>
    </div>
    <nav class="flex flex-col gap-1" aria-label="main">
      ${NAV.map(([id, ic]) => `<button class="nav-item" data-nav="${id}" ${APP.page === id ? 'aria-current="page"' : ''}>${icon(ic, 'w-[18px] h-[18px]')}<span>${t('nav.' + id)}</span>${id === 'train' && training ? `<span class="ms-auto w-2 h-2 rounded-full bg-mint-400 animate-pulse" title="${t('side.training')}"></span>` : ''}</button>`).join('')}
    </nav>
    <div class="mt-auto flex flex-col gap-3">
      <button data-nav="models" class="text-start rounded-xl border border-ink-700 bg-ink-850 p-3 hover:border-ink-500 transition">
        <div class="text-[11px] text-ink-400 mb-1">${t('side.model')}</div>
        <div class="flex items-center gap-2 text-sm font-medium">${icon('models', 'w-4 h-4 text-mint-300 shrink-0')}<span class="truncate ltr">${active ? esc(active) : `<span class="text-ink-400" style="unicode-bidi:normal">${t('side.none')}</span>`}</span></div>
      </button>
      <div class="flex items-center justify-between text-xs text-ink-300 px-1">
        <span class="flex items-center gap-2"><span class="w-2 h-2 rounded-full ${engine.cls}"></span>${t('side.engine')}: ${engine.txt}</span>
        <span class="flex"><button class="btn btn-ghost btn-sm !px-2" data-theme-cycle title="${t('s.theme')}: ${t('theme.' + THEME.mode)}">${icon({ system: 'monitor', dark: 'moon', light: 'sun' }[THEME.mode], 'w-4 h-4')}</button>
        <button class="btn btn-ghost btn-sm !px-2" data-lang title="Language">${icon('globe', 'w-4 h-4')}<span class="font-bold">${I18N.lang === 'fa' ? 'EN' : 'فا'}</span></button></span>
      </div>
      <p class="text-[10.5px] leading-relaxed text-ink-500 px-1">${t('disclaimer')}</p>
    </div>`;
}

function bindSidebar() {
  $('#sidebar').addEventListener('click', (e) => {
    const nav = e.target.closest('[data-nav]');
    if (nav) return go(nav.dataset.nav);
    if (e.target.closest("[data-theme-cycle]")) return THEME.cycle();
    if (e.target.closest('[data-lang]')) switchLang();
  });
}

function switchLang() {
  I18N.set(I18N.lang === 'fa' ? 'en' : 'fa');
  native.setSettings({ lang: I18N.lang }).catch(() => {});
  renderSidebar();
  mountAllPages();
  renderOverlay();
}

/* ------------------------------------------------------------ router */
function mountAllPages() {
  for (const id in APP.pages) {
    APP.roots[id].innerHTML = '';
    APP.pages[id].mount(APP.roots[id]);
  }
}

function go(id) {
  if (!APP.pages[id]) return;
  const prev = APP.page;
  if (prev !== id && APP.pages[prev] && APP.pages[prev].hide) APP.pages[prev].hide();
  APP.page = id;
  for (const k in APP.roots) APP.roots[k].classList.toggle('hidden', k !== id);
  renderSidebar();
  if (APP.pages[id].show) APP.pages[id].show();
}

function registerPage(id, page) { APP.pages[id] = page; }

/* ------------------------------------------------------------ health polling */
async function pollHealth() {
  if (APP.backend.state === 'ready') {
    try {
      const prevActive = APP.health && APP.health.active;
      const prevTf = APP.health && APP.health.tf && APP.health.tf.state;
      APP.health = await API.call('/health');
      if (prevActive !== APP.health.active || prevTf !== APP.health.tf.state || true) renderSidebar();
      if (prevActive !== APP.health.active) document.dispatchEvent(new CustomEvent('active-model-changed'));
      renderOverlay();
    } catch { /* engine busy or gone */ }
  }
  setTimeout(pollHealth, 1500);
}

/* ------------------------------------------------------------ setup overlay */
function overlayMode() {
  const b = APP.backend;
  if (b.state === 'starting') return 'starting';
  if (b.state === 'error') return 'error';
  if (APP.health && APP.health.tf && APP.health.tf.state === 'error') return 'tf-error';
  if (!APP.health) return 'starting';
  return null;
}

function renderOverlay() {
  const el = $('#boot');
  const mode = overlayMode();
  if (!mode) { el.classList.add('hidden'); el.innerHTML = ''; el.dataset.mode = ''; return; }
  el.classList.remove('hidden');
  if (mode === 'starting') {
    el.dataset.mode = mode;
    el.innerHTML = `<div class="flex flex-col items-center gap-4 text-ink-200">${spinner('w-8 h-8 text-mint-400')}<div>${t('boot.starting')}</div></div>`;
    return;
  }
  // keep the install log intact across re-renders
  const logText = $('#install-log') ? $('#install-log').textContent : '';
  const detail = mode === 'tf-error' ? (APP.health.tf.error || '') : [(APP.backend.message || ''), (APP.backend.tried || []).join('\n'), APP.backend.stderr || ''].filter(Boolean).join('\n\n');
  if (el.dataset.mode === mode && $('#boot-py')) return; // already rendered; avoid wiping inputs
  el.dataset.mode = mode;
  el.innerHTML = `
    <div class="card w-full max-w-2xl p-7 shadow-2xl animate-fadeUp max-h-[92vh] overflow-auto">
      <div class="flex items-start gap-4">
        <div class="w-11 h-11 rounded-xl grid place-items-center bg-amber-400/10 text-amber-400 ring-1 ring-amber-400/30 shrink-0">${icon('cpu', 'w-5 h-5')}</div>
        <div><h2 class="text-lg font-bold">${t('boot.errTitle')}</h2>
        <p class="text-sm text-ink-300 mt-1.5 leading-7">${mode === 'tf-error' ? t('boot.tfErr') + ' ' : ''}${t('boot.errBody')}</p></div>
      </div>
      <details class="mt-4 rounded-xl border border-ink-700 bg-ink-900"><summary class="cursor-pointer px-4 py-2.5 text-xs text-ink-300">${t('boot.details')}</summary>
        <pre class="px-4 pb-4 text-[11px] leading-5 text-ink-300 whitespace-pre-wrap break-all max-h-40 overflow-auto ltr">${esc(detail || '—')}</pre></details>
      <div class="mt-5"><label class="label">${t('s.python')}</label>
        <div class="flex gap-2"><input id="boot-py" class="field ltr font-mono text-xs" placeholder="C:\\Python311\\python.exe  |  /usr/bin/python3" />
        <button class="btn" id="boot-browse">${icon('folder', 'w-4 h-4')}</button></div></div>
      <div class="mt-5 flex flex-wrap gap-2">
        <button class="btn btn-primary" id="boot-install">${icon('download', 'w-4 h-4')}${t('s.install')}</button>
        <button class="btn" id="boot-apply">${icon('refresh', 'w-4 h-4')}${t('s.apply')}</button>
      </div>
      <p class="text-xs text-ink-400 mt-3 leading-6">${t('s.installHint')}</p>
      <pre id="install-log" class="mt-4 hidden rounded-xl bg-ink-950 border border-ink-700 p-3 text-[11px] leading-5 text-ink-300 h-44 overflow-auto whitespace-pre-wrap ltr">${esc(logText)}</pre>
    </div>`;
  if (logText) $('#install-log').classList.remove('hidden');
  native.getSettings().then((s) => { if (s.pythonPath && $('#boot-py')) $('#boot-py').value = s.pythonPath; });
  $('#boot-browse').onclick = async () => { const p = await native.pickPython(); if (p) $('#boot-py').value = p; };
  $('#boot-apply').onclick = async () => {
    await native.setSettings({ pythonPath: $('#boot-py').value.trim() });
    el.dataset.mode = 'starting'; el.innerHTML = `<div class="flex flex-col items-center gap-4">${spinner('w-8 h-8 text-mint-400')}<div>${t('boot.starting')}</div></div>`;
    await native.restartBackend();
  };
  $('#boot-install').onclick = runInstall;
}

async function runInstall() {
  if (APP.installing) return;
  APP.installing = true;
  const btn = $('#boot-install') || $('#set-install');
  const log = $('#install-log');
  if (log) { log.classList.remove('hidden'); log.textContent = ''; }
  if (btn) { btn.disabled = true; btn.innerHTML = `${spinner('w-4 h-4')}${t('boot.installing')}`; }
  const r = await native.installDeps();
  APP.installing = false;
  if (!r.ok && log) log.textContent += `\n✗ ${r.error}\n`;
  else toast(t('boot.installDone'), 'ok');
  if (btn) { btn.disabled = false; btn.innerHTML = `${icon('download', 'w-4 h-4')}${t('s.install')}`; }
}

/* ------------------------------------------------------------ boot */
function onBackendStatus(st) {
  const wasReady = APP.backend.state === 'ready';
  APP.backend = st;
  if (st.state !== 'ready') APP.health = null;
  if (st.state === 'ready' && !wasReady) {
    API.call('/health').then((h) => { APP.health = h; renderSidebar(); renderOverlay(); document.dispatchEvent(new CustomEvent('backend-ready')); });
  }
  renderSidebar();
  renderOverlay();
}

async function boot() {
  I18N.init();
  document.addEventListener('dragover', (e) => e.preventDefault());
  document.addEventListener('drop', (e) => e.preventDefault());
  native.onInstallLog((txt) => { const l = $('#install-log'); if (l) { l.classList.remove('hidden'); l.textContent += txt; l.scrollTop = l.scrollHeight; } });
  native.onBackend(onBackendStatus);

  const view = $('#view');
  for (const [id] of NAV) {
    const div = document.createElement('section');
    div.id = 'page-' + id;
    div.className = 'hidden h-full';
    view.appendChild(div);
    APP.roots[id] = div;
  }
  document.addEventListener('theme-changed', () => { renderSidebar(); if (APP.pages.settings) APP.pages.settings.mount(APP.roots.settings); if (APP.page === 'train') trDraw(); });
  bindSidebar();
  renderSidebar();
  renderOverlay();
  mountAllPages();
  go('predict');
  onBackendStatus(await native.getBackend());
  pollHealth();
}

window.addEventListener('DOMContentLoaded', boot);
