/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./renderer/**/*.{html,js}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Vazirmatn', 'system-ui', 'Segoe UI', 'sans-serif'], mono: ['ui-monospace', 'Cascadia Code', 'Consolas', 'monospace'] },
      colors: (() => {
          const v = (n) => `rgb(var(--${n}) / <alpha-value>)`;
          const scale = (p, keys) => Object.fromEntries(keys.map((k) => [k, v(`${p}-${k}`)]));
          return {
            ink: scale('ink', [50, 100, 200, 300, 400, 500, 600, 700, 800, 850, 900, 950]),
            mint: scale('mint', [300, 400, 500, 600]),
            rose: scale('rose', [400, 500]),
            amber: scale('amber', [400]),
            sky: scale('sky', [400]),
          };
        })(),
      boxShadow: { glow: '0 0 0 1px rgba(63,224,200,.25), 0 8px 30px -8px rgba(63,224,200,.25)' },
      keyframes: { fadeUp: { from: { opacity: 0, transform: 'translateY(6px)' }, to: { opacity: 1, transform: 'none' } } },
      animation: { fadeUp: 'fadeUp .25s ease-out both' },
    },
  },
  plugins: [],
};
